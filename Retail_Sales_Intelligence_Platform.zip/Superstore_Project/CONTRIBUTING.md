# Contributing to Retail Sales Intelligence Platform

Thank you for your interest in contributing! This document outlines the process and standards for contributing to this project.

---

## 📋 Table of Contents
- [Getting Started](#getting-started)
- [Project Structure](#project-structure)
- [Development Workflow](#development-workflow)
- [Code Standards](#code-standards)
- [Adding New Features](#adding-new-features)
- [Reporting Bugs](#reporting-bugs)

---

## Getting Started

```bash
# Fork the repo, then clone your fork
git clone https://github.com/YOUR_USERNAME/Retail-Sales-Intelligence-Platform.git
cd Retail-Sales-Intelligence-Platform

# Create virtual environment
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Run the pipeline to verify setup
python data_cleaning.py
python eda.py
streamlit run app.py
```

---

## Development Workflow

```bash
# 1. Create a feature branch
git checkout -b feature/your-feature-name

# 2. Make your changes with clear commits
git add .
git commit -m "feat: add cohort analysis to customer tab"

# 3. Push and open a Pull Request
git push origin feature/your-feature-name
```

### Commit Message Format
Follow conventional commits:
```
feat:     New feature
fix:      Bug fix
docs:     Documentation update
refactor: Code restructure (no feature change)
perf:     Performance improvement
test:     Adding tests
chore:    Config / dependency changes
```

---

## Code Standards

- **Python 3.10+** — use type hints where possible
- **PEP 8** formatting (max line length: 100)
- **Docstrings** on all functions
- **No hardcoded values** — use constants at the top of each file
- All chart functions must call `plt.close()` after `st.pyplot(fig)` to avoid memory leaks

### Example function style:
```python
def compute_rfm(df: pd.DataFrame, snapshot_date: pd.Timestamp = None) -> pd.DataFrame:
    """
    Compute RFM scores for each customer.

    Args:
        df: Cleaned transaction DataFrame with order_date, customer_id, sales columns.
        snapshot_date: Reference date for recency. Defaults to max order_date.

    Returns:
        DataFrame with columns: customer_id, Recency, Frequency, Monetary, Label
    """
    ...
```

---

## Adding New Features

### New Analysis Module
1. Create `your_analysis.py` in the root directory
2. Follow the same pipeline pattern: `load_data()` → `compute_*()` → `plot_*()` → `save_*()`
3. Add a corresponding tab in `app.py`
4. Document in `README.md` under Module Breakdown

### New Dashboard Tab
1. Add `tab_your_feature(df: pd.DataFrame)` function in `app.py`
2. Register it in `main()` under `st.tabs([...])`
3. All insights must be **dynamic** — computed from the filtered `df`, never hardcoded strings

### New SQL Query
1. Add to `sql/superstore_analysis.sql` with a numbered comment header
2. Add the corresponding key and query string to the `queries` dict in `business_analysis.py`

---

## Reporting Bugs

Open an issue with:
- Python version (`python --version`)
- OS (Windows / Mac / Linux)
- Error message (full traceback)
- Steps to reproduce

---

## Ideas for Contributions

- [ ] Choropleth map (US states) using Plotly
- [ ] Customer cohort retention analysis
- [ ] Product recommendation engine (collaborative filtering)
- [ ] Streamlit Cloud deployment config
- [ ] Unit tests with `pytest`
- [ ] Docker setup

---

*This project follows the MIT License. By contributing, you agree your contributions will be licensed under the same terms.*
