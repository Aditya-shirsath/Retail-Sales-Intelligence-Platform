"""
================================================================
  Retail Sales Intelligence Platform
  Module : business_analysis.py
  — SQLite queries, RFM, Segmentation, Executive Report
================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import sqlite3, os

BI_PATH   = "data/superstore_bi.csv"
DB_PATH   = "retail_sales.db"
RPT_DIR   = "reports"
CHART_DIR = "reports/charts"


def _save(name):
    os.makedirs(CHART_DIR, exist_ok=True)
    plt.tight_layout()
    plt.savefig(f"{CHART_DIR}/{name}", dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   [✓] {CHART_DIR}/{name}")

def _fmt_k(x, _): return f"${x/1_000:.0f}K"


# ── DATABASE ─────────────────────────────────────────────────
def load_to_sqlite(df: pd.DataFrame) -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    df.to_sql("sales", conn, if_exists="replace", index=False)
    n = pd.read_sql("SELECT COUNT(*) FROM sales", conn).iloc[0,0]
    print(f"[✓] SQLite '{DB_PATH}'  →  {n:,} rows")
    return conn


def run_sql_queries(conn: sqlite3.Connection) -> dict:
    queries = {
        "01_region_summary": """
            SELECT region,
                   ROUND(SUM(sales),2)   AS Total_Sales,
                   ROUND(SUM(profit),2)  AS Total_Profit,
                   COUNT(DISTINCT order_id) AS Orders,
                   ROUND(SUM(profit)/SUM(sales)*100,2) AS Margin_Pct
            FROM   sales
            GROUP  BY region
            ORDER  BY Total_Sales DESC
        """,
        "02_category_summary": """
            SELECT category,
                   ROUND(SUM(sales),2)   AS Revenue,
                   ROUND(SUM(profit),2)  AS Profit,
                   COUNT(*)              AS Rows,
                   ROUND(AVG(sales),2)   AS Avg_Sale,
                   ROUND(SUM(profit)/SUM(sales)*100,2) AS Margin_Pct
            FROM   sales
            GROUP  BY category
            ORDER  BY Revenue DESC
        """,
        "03_subcategory_profit": """
            SELECT sub_category,
                   ROUND(SUM(sales),2)  AS Revenue,
                   ROUND(SUM(profit),2) AS Profit,
                   ROUND(SUM(profit)/SUM(sales)*100,2) AS Margin_Pct
            FROM   sales
            GROUP  BY sub_category
            ORDER  BY Profit DESC
        """,
        "04_top10_customers": """
            SELECT customer_name,
                   segment,
                   ROUND(SUM(sales),2)  AS Revenue,
                   ROUND(SUM(profit),2) AS Profit,
                   COUNT(DISTINCT order_id) AS Orders
            FROM   sales
            GROUP  BY customer_name
            ORDER  BY Revenue DESC
            LIMIT  10
        """,
        "05_top10_states": """
            SELECT state,
                   region,
                   ROUND(SUM(sales),2)  AS Revenue,
                   ROUND(SUM(profit),2) AS Profit
            FROM   sales
            GROUP  BY state
            ORDER  BY Revenue DESC
            LIMIT  10
        """,
        "06_segment_analysis": """
            SELECT segment,
                   ROUND(SUM(sales),2)  AS Revenue,
                   ROUND(SUM(profit),2) AS Profit,
                   COUNT(DISTINCT customer_id) AS Customers,
                   COUNT(DISTINCT order_id)    AS Orders
            FROM   sales
            GROUP  BY segment
            ORDER  BY Revenue DESC
        """,
        "07_shipmode_analysis": """
            SELECT ship_mode,
                   ROUND(SUM(sales),2)  AS Revenue,
                   ROUND(SUM(profit),2) AS Profit,
                   COUNT(*)             AS Orders,
                   ROUND(AVG(ship_days),1) AS Avg_Ship_Days
            FROM   sales
            GROUP  BY ship_mode
            ORDER  BY Revenue DESC
        """,
        "08_quarterly_trend": """
            SELECT order_year   AS Year,
                   quarter_label AS Quarter,
                   ROUND(SUM(sales),2)  AS Sales,
                   ROUND(SUM(profit),2) AS Profit
            FROM   sales
            GROUP  BY order_year, quarter_label
            ORDER  BY order_year, quarter_label
        """,
        "09_discount_impact": """
            SELECT
                CASE
                    WHEN discount = 0          THEN '0%'
                    WHEN discount <= 0.10      THEN '1-10%'
                    WHEN discount <= 0.20      THEN '11-20%'
                    WHEN discount <= 0.40      THEN '21-40%'
                    ELSE                            '40%+'
                END AS Discount_Band,
                COUNT(*)             AS Orders,
                ROUND(SUM(sales),2)  AS Revenue,
                ROUND(SUM(profit),2) AS Profit,
                ROUND(AVG(profit),2) AS Avg_Profit
            FROM   sales
            GROUP  BY Discount_Band
            ORDER  BY Discount_Band
        """,
        "10_loss_making_products": """
            SELECT product_name,
                   category,
                   sub_category,
                   ROUND(SUM(sales),2)  AS Revenue,
                   ROUND(SUM(profit),2) AS Loss
            FROM   sales
            GROUP  BY product_name
            HAVING SUM(profit) < 0
            ORDER  BY Loss ASC
            LIMIT  15
        """,
    }

    results = {}
    sep = "=" * 60
    for label, sql in queries.items():
        df = pd.read_sql(sql, conn)
        results[label] = df
        print(f"\n{sep}\n  {label.upper()}\n{sep}")
        print(df.to_string(index=False))
    return results


# ── RFM ANALYSIS ─────────────────────────────────────────────
def build_rfm(df: pd.DataFrame) -> pd.DataFrame:
    snapshot = df["order_date"].max()
    rfm = (df.groupby("customer_id")
             .agg(
                 Customer_Name = ("customer_name", "first"),
                 Segment       = ("segment",       "first"),
                 Recency       = ("order_date",    lambda x: (snapshot - x.max()).days),
                 Frequency     = ("order_id",      "nunique"),
                 Monetary      = ("sales",         "sum"),
             )
             .reset_index())
    rfm["Monetary"] = rfm["Monetary"].round(2)

    # Score 1–4 (qcut)
    rfm["R_Score"] = pd.qcut(rfm["Recency"],  4, labels=[4,3,2,1]).astype(int)
    rfm["F_Score"] = pd.qcut(rfm["Frequency"].rank(method="first"),
                              4, labels=[1,2,3,4]).astype(int)
    rfm["M_Score"] = pd.qcut(rfm["Monetary"], 4, labels=[1,2,3,4]).astype(int)
    rfm["RFM_Score"] = rfm["R_Score"] + rfm["F_Score"] + rfm["M_Score"]

    def segment_label(score):
        if score >= 10: return "Champions"
        if score >= 8:  return "Loyal"
        if score >= 6:  return "At Risk"
        return "Lost"

    rfm["RFM_Segment"] = rfm["RFM_Score"].apply(segment_label)

    print("\n" + "="*60 + "\n  RFM SEGMENTS\n" + "="*60)
    print(rfm["RFM_Segment"].value_counts().to_string())
    print("\nRFM Sample:")
    print(rfm.head(8).to_string(index=False))
    return rfm


def plot_rfm(rfm: pd.DataFrame) -> None:
    counts = rfm["RFM_Segment"].value_counts()
    colors = {"Champions":"#1565C0","Loyal":"#43A047",
              "At Risk":"#FB8C00","Lost":"#E53935"}

    fig, axes = plt.subplots(1, 2, figsize=(13, 5))

    # Bar
    bar_colors = [colors.get(c,"grey") for c in counts.index]
    axes[0].bar(counts.index, counts.values, color=bar_colors, edgecolor="white")
    for i, v in enumerate(counts.values):
        axes[0].text(i, v+2, str(v), ha="center", fontweight="bold")
    axes[0].set_title("RFM Customer Segments", fontweight="bold", fontsize=13)
    axes[0].set_ylabel("Customers")
    axes[0].grid(axis="y", alpha=0.3)
    axes[0].spines[["top","right"]].set_visible(False)

    # Monetary by segment
    mon = rfm.groupby("RFM_Segment")["Monetary"].sum().sort_values(ascending=False)
    axes[1].bar(mon.index, mon.values,
                color=[colors.get(c,"grey") for c in mon.index], edgecolor="white")
    axes[1].set_title("Revenue by RFM Segment", fontweight="bold", fontsize=13)
    axes[1].set_ylabel("Revenue ($)")
    axes[1].yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    axes[1].grid(axis="y", alpha=0.3)
    axes[1].spines[["top","right"]].set_visible(False)

    _save("11_rfm_segments.png")


# ── CUSTOMER SEGMENTATION ────────────────────────────────────
def build_customer_segments(df: pd.DataFrame) -> pd.DataFrame:
    seg = (df.groupby("customer_id")
             .agg(Customer_Name=("customer_name","first"),
                  Segment=("segment","first"),
                  Total_Sales=("sales","sum"),
                  Total_Profit=("profit","sum"),
                  Total_Orders=("order_id","nunique"))
             .reset_index())
    seg["Value_Tier"] = pd.qcut(
        seg["Total_Sales"], q=3,
        labels=["Bronze","Silver","Gold"])
    print("\n[✓] Customer Value Tiers:")
    print(seg["Value_Tier"].value_counts().to_string())
    return seg


def plot_top10_customers(seg: pd.DataFrame) -> None:
    top10 = seg.nlargest(10, "Total_Sales")
    fig, ax = plt.subplots(figsize=(12, 5))
    colors = plt.cm.Blues(np.linspace(0.5, 0.9, len(top10)))
    bars = ax.bar(top10["Customer_Name"], top10["Total_Sales"],
                  color=colors, edgecolor="white")
    ax.bar_label(bars, fmt="$%.0f", padding=3, fontsize=8, fontweight="bold")
    ax.set_title("Top 10 Customers by Revenue", fontsize=14, fontweight="bold")
    ax.set_ylabel("Total Sales ($)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    plt.xticks(rotation=40, ha="right", fontsize=8)
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("12_top10_customers.png")


# ── EXECUTIVE REPORT ─────────────────────────────────────────
def build_executive_report(df: pd.DataFrame) -> pd.DataFrame:
    total_sales     = df["sales"].sum()
    total_profit    = df["profit"].sum()
    total_orders    = df["order_id"].nunique()
    total_customers = df["customer_id"].nunique()
    avg_order       = df.groupby("order_id")["sales"].sum().mean()
    margin          = total_profit / total_sales * 100
    top_region      = df.groupby("region")["sales"].sum().idxmax()
    top_category    = df.groupby("category")["sales"].sum().idxmax()
    top_state       = df.groupby("state")["sales"].sum().idxmax()
    top_segment     = df.groupby("segment")["sales"].sum().idxmax()
    loss_pct        = (df["profit"] < 0).mean() * 100

    report = pd.DataFrame({
        "Metric": [
            "Total Sales","Total Profit","Total Orders","Total Customers",
            "Avg Order Value","Profit Margin (%)","Top Region",
            "Top Category","Top State","Top Segment","Loss Order %",
        ],
        "Value": [
            f"${total_sales:,.2f}", f"${total_profit:,.2f}",
            f"{total_orders:,}", f"{total_customers:,}",
            f"${avg_order:,.2f}", f"{margin:.2f}%",
            top_region, top_category, top_state, top_segment,
            f"{loss_pct:.1f}%",
        ],
    })

    os.makedirs(RPT_DIR, exist_ok=True)
    report.to_csv(f"{RPT_DIR}/executive_report.csv", index=False)

    with open(f"{RPT_DIR}/business_insights.txt", "w") as f:
        f.write("SUPERSTORE — BUSINESS INSIGHTS REPORT\n")
        f.write("=" * 45 + "\n\n")
        for _, row in report.iterrows():
            f.write(f"{row['Metric']:<25}: {row['Value']}\n")
        f.write("\n\nKEY FINDINGS\n" + "-"*45 + "\n")
        f.write("1. Technology is the highest-profit category (margin ~17%).\n")
        f.write("2. Furniture is barely profitable despite high sales volume.\n")
        f.write("3. Tables & Bookcases sub-categories are net loss-makers.\n")
        f.write("4. Higher discounts (>20%) strongly correlate with losses.\n")
        f.write("5. West region leads in both Sales and Profit.\n")
        f.write("6. Standard Class shipping dominates order volume.\n")

    print(f"\n[✓] Reports saved to {RPT_DIR}/")
    print("\n" + "="*60 + "\n  EXECUTIVE SUMMARY\n" + "="*60)
    print(report.to_string(index=False))
    return report


def save_outputs(seg, rfm, results):
    os.makedirs(RPT_DIR, exist_ok=True)
    seg.to_csv(f"{RPT_DIR}/customer_segmentation.csv",  index=False)
    rfm.to_csv(f"{RPT_DIR}/rfm_analysis.csv",           index=False)
    for label, df_r in results.items():
        df_r.to_csv(f"{RPT_DIR}/sql_{label}.csv", index=False)
    print(f"[✓] All CSV outputs saved to {RPT_DIR}/")


# ── MAIN ─────────────────────────────────────────────────────
def run_business_analysis() -> None:
    print("\n" + "="*60)
    print("  SUPERSTORE — BUSINESS ANALYSIS")
    print("="*60)

    df = pd.read_csv(BI_PATH, parse_dates=["order_date","ship_date"])
    print(f"[✓] Loaded  →  {len(df):,} rows")

    conn    = load_to_sqlite(df)
    results = run_sql_queries(conn)
    conn.close()

    rfm = build_rfm(df)
    plot_rfm(rfm)

    seg = build_customer_segments(df)
    plot_top10_customers(seg)

    build_executive_report(df)
    save_outputs(seg, rfm, results)
    print("\n[✓] Business analysis complete.\n")


if __name__ == "__main__":
    run_business_analysis()
