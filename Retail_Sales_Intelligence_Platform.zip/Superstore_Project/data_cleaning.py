"""
================================================================
  Retail Sales Intelligence Platform
  Module : data_cleaning.py
  Dataset: Kaggle — Sample Superstore (9,994 real transactions)
================================================================
"""

import pandas as pd
import numpy as np
import os

RAW_PATH   = "data/superstore.csv"
CLEAN_PATH = "data/clean_superstore.csv"
BI_PATH    = "data/superstore_bi.csv"


# ── 1. LOAD ──────────────────────────────────────────────────
def load_raw(path: str = RAW_PATH) -> pd.DataFrame:
    df = pd.read_csv(path, encoding="latin-1")
    print(f"[✓] Loaded raw data  →  {df.shape[0]:,} rows × {df.shape[1]} cols")
    return df


# ── 2. INSPECT ───────────────────────────────────────────────
def inspect(df: pd.DataFrame) -> None:
    sep = "=" * 60
    print(f"\n{sep}\n  SHAPE\n{sep}")
    print(df.shape)

    print(f"\n{sep}\n  COLUMNS & DTYPES\n{sep}")
    print(df.dtypes.to_string())

    print(f"\n{sep}\n  MISSING VALUES\n{sep}")
    print(df.isnull().sum().to_string())

    print(f"\n{sep}\n  DUPLICATES\n{sep}")
    print(f"Duplicate rows : {df.duplicated().sum()}")

    print(f"\n{sep}\n  NUMERICAL SUMMARY\n{sep}")
    print(df[["Sales", "Quantity", "Discount", "Profit"]].describe().round(2))

    print(f"\n{sep}\n  UNIQUE VALUE COUNTS\n{sep}")
    for col in ["Region", "Category", "Sub-Category", "Segment", "Ship Mode"]:
        print(f"  {col:<15}: {df[col].unique().tolist()}")


# ── 3. CLEAN ─────────────────────────────────────────────────
def clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()

    # Parse dates
    df["Order Date"] = pd.to_datetime(df["Order Date"], format="%m/%d/%Y")
    df["Ship Date"]  = pd.to_datetime(df["Ship Date"],  format="%m/%d/%Y")
    print("[✓] Dates parsed to datetime64")

    # Rename columns — snake_case
    df.columns = (df.columns
                    .str.strip()
                    .str.lower()
                    .str.replace(" ", "_")
                    .str.replace("-", "_"))

    # Drop unused column
    df.drop(columns=["row_id", "country", "postal_code"], inplace=True, errors="ignore")
    print("[✓] Unnecessary columns dropped")

    # Remove duplicates
    before = len(df)
    df.drop_duplicates(inplace=True)
    print(f"[✓] Duplicates removed  →  {before - len(df)} rows dropped")

    # Remove nulls
    before = len(df)
    df.dropna(inplace=True)
    print(f"[✓] Nulls removed       →  {before - len(df)} rows dropped")

    # Derived metric
    df["profit_margin_pct"] = (df["profit"] / df["sales"] * 100).round(2)

    df.reset_index(drop=True, inplace=True)
    print(f"[✓] Final clean shape   →  {df.shape[0]:,} rows × {df.shape[1]} cols")
    return df


# ── 4. ENRICH ────────────────────────────────────────────────
def enrich(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["order_year"]    = df["order_date"].dt.year
    df["order_month"]   = df["order_date"].dt.month
    df["month_name"]    = df["order_date"].dt.strftime("%B")
    df["quarter"]       = df["order_date"].dt.quarter
    df["quarter_label"] = "Q" + df["quarter"].astype(str)
    df["ship_days"]     = (df["ship_date"] - df["order_date"]).dt.days
    df["is_profitable"] = df["profit"] > 0
    print("[✓] Features added  →  year, month, quarter, ship_days, is_profitable")
    return df


# ── 5. SAVE ──────────────────────────────────────────────────
def save(df: pd.DataFrame, path: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    df.to_csv(path, index=False)
    print(f"[✓] Saved  →  {path}  ({len(df):,} rows)")


# ── PIPELINE ─────────────────────────────────────────────────
def run_pipeline() -> pd.DataFrame:
    print("\n" + "=" * 60)
    print("  SUPERSTORE — DATA CLEANING PIPELINE")
    print("=" * 60)
    df_raw    = load_raw()
    inspect(df_raw)
    df_clean  = clean(df_raw)
    save(df_clean, CLEAN_PATH)
    df_bi     = enrich(df_clean)
    save(df_bi, BI_PATH)
    print("\n[✓] Pipeline complete.\n")
    return df_bi


if __name__ == "__main__":
    run_pipeline()
