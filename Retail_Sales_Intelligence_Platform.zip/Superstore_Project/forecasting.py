"""
================================================================
  Retail Sales Intelligence Platform
  Module : forecasting.py
  Purpose: 90-day Sales & Profit Forecast using Prophet
  Run    : python forecasting.py
================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import os, warnings
warnings.filterwarnings("ignore")

BI_PATH    = "data/superstore_bi.csv"
CHART_DIR  = "reports/charts"
REPORT_DIR = "reports"


def load_data() -> pd.DataFrame:
    paths = ["data/superstore_bi.csv", "data/clean_superstore.csv", "data/superstore.csv"]
    for p in paths:
        if os.path.exists(p):
            df = pd.read_csv(p, encoding="latin-1")
            df.columns = (df.columns.str.strip().str.lower()
                          .str.replace(" ", "_").str.replace("-", "_"))
            df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
            print(f"[✓] Loaded  →  {p}  ({len(df):,} rows)")
            return df
    raise FileNotFoundError("No data file found. Run data_cleaning.py first.")


def build_daily_series(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate to daily sales & profit for Prophet."""
    daily = (df.groupby("order_date")
               .agg(sales=("sales", "sum"), profit=("profit", "sum"))
               .reset_index()
               .rename(columns={"order_date": "ds", "sales": "y"}))
    daily["profit"] = daily["profit"]
    daily = daily.sort_values("ds").reset_index(drop=True)
    print(f"[✓] Daily series built  →  {len(daily)} days")
    return daily


def run_prophet_forecast(daily: pd.DataFrame, col: str = "y",
                          periods: int = 90, label: str = "Sales") -> pd.DataFrame:
    """Run Prophet forecast. Returns forecast DataFrame."""
    try:
        from prophet import Prophet
    except ImportError:
        print("[!] Prophet not installed. Run: pip install prophet")
        return None

    df_prophet = daily[["ds", col]].rename(columns={col: "y"})

    model = Prophet(
        yearly_seasonality=True,
        weekly_seasonality=True,
        daily_seasonality=False,
        seasonality_mode="multiplicative",
        changepoint_prior_scale=0.05,
    )
    model.fit(df_prophet)

    future   = model.make_future_dataframe(periods=periods, freq="D")
    forecast = model.predict(future)
    print(f"[✓] Prophet {label} forecast complete  →  {periods} days ahead")
    return forecast, model, df_prophet


def plot_sales_forecast(daily, forecast, df_actual):
    """Sales forecast chart — actual + predicted + confidence interval."""
    os.makedirs(CHART_DIR, exist_ok=True)

    last_actual = daily["ds"].max()
    hist = forecast[forecast["ds"] <= last_actual]
    fut  = forecast[forecast["ds"] >  last_actual]

    fig, ax = plt.subplots(figsize=(14, 5))
    fig.patch.set_facecolor("#F5F7FA")
    ax.set_facecolor("#F5F7FA")

    # Actual data
    ax.plot(daily["ds"], daily["y"], color="#1565C0", lw=1.8,
            label="Actual Sales", zorder=3)

    # Historical fit
    ax.plot(hist["ds"], hist["yhat"], color="#42A5F5", lw=1.2,
            ls="--", label="Model Fit", alpha=0.7)

    # Future forecast
    ax.plot(fut["ds"], fut["yhat"], color="#E65100", lw=2.2,
            label="Forecast (90 days)", zorder=4)
    ax.fill_between(fut["ds"], fut["yhat_lower"], fut["yhat_upper"],
                    alpha=0.2, color="#E65100", label="95% Confidence")

    # Divider line
    ax.axvline(last_actual, color="gray", ls=":", lw=1.5, label="Forecast Start")

    ax.set_title("📈 Sales Forecast — Next 90 Days (Prophet)",
                 fontsize=14, fontweight="bold", pad=14, color="#1A1A2E")
    ax.set_xlabel("Date", fontsize=10)
    ax.set_ylabel("Daily Sales ($)", fontsize=10)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.legend(loc="upper left", fontsize=9)
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)

    plt.tight_layout()
    path = f"{CHART_DIR}/07_sales_forecast.png"
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"[✓] Saved  →  {path}")
    return path


def plot_seasonality(model, label="Sales"):
    """Plot weekly + yearly seasonality components."""
    os.makedirs(CHART_DIR, exist_ok=True)

    fig = model.plot_components(model.predict(
        model.make_future_dataframe(periods=1)))
    fig.suptitle(f"{label} Seasonality Components", fontweight="bold", y=1.01)
    path = f"{CHART_DIR}/08_{label.lower()}_seasonality.png"
    plt.savefig(path, dpi=120, bbox_inches="tight")
    plt.close()
    print(f"[✓] Saved  →  {path}")


def save_forecast_csv(forecast, label="sales"):
    """Save forecast to CSV for downstream use."""
    os.makedirs(REPORT_DIR, exist_ok=True)
    out = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
    out.columns = ["date", "forecast", "lower_bound", "upper_bound"]
    out["forecast"]    = out["forecast"].round(2)
    out["lower_bound"] = out["lower_bound"].round(2)
    out["upper_bound"] = out["upper_bound"].round(2)
    path = f"{REPORT_DIR}/{label}_forecast.csv"
    out.to_csv(path, index=False)
    print(f"[✓] Forecast CSV saved  →  {path}")
    return path


def compute_forecast_summary(forecast, last_actual_date) -> dict:
    """KPI summary for the forecast period."""
    fut = forecast[forecast["ds"] > last_actual_date].copy()
    return {
        "forecast_start":  str(last_actual_date.date()),
        "forecast_end":    str(fut["ds"].max().date()),
        "total_forecast":  round(fut["yhat"].sum(), 2),
        "avg_daily":       round(fut["yhat"].mean(), 2),
        "peak_day":        str(fut.loc[fut["yhat"].idxmax(), "ds"].date()),
        "peak_value":      round(fut["yhat"].max(), 2),
        "lower_90d":       round(fut["yhat_lower"].sum(), 2),
        "upper_90d":       round(fut["yhat_upper"].sum(), 2),
    }


def run_pipeline():
    print("\n" + "=" * 60)
    print("  SUPERSTORE — FORECASTING PIPELINE (Prophet)")
    print("=" * 60)

    df    = load_data()
    daily = build_daily_series(df)

    # Sales forecast
    result = run_prophet_forecast(daily, col="y", periods=90, label="Sales")
    if result is None:
        return

    forecast, model, df_actual = result
    plot_sales_forecast(daily, forecast, df_actual)
    plot_seasonality(model, "Sales")
    save_forecast_csv(forecast, "sales")

    summary = compute_forecast_summary(forecast, daily["ds"].max())
    print("\n── FORECAST SUMMARY ──────────────────────────────")
    for k, v in summary.items():
        print(f"   {k:<20}: {v}")

    # Save summary
    pd.DataFrame([summary]).to_csv(f"{REPORT_DIR}/forecast_summary.csv", index=False)
    print(f"\n[✓] Pipeline complete.\n")
    return forecast, summary


if __name__ == "__main__":
    run_pipeline()
