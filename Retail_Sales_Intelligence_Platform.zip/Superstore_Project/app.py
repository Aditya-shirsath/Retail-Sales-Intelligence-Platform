"""
================================================================
  Retail Sales Intelligence Platform
  Module : app.py  —  Streamlit Dashboard
  Run    : streamlit run app.py
  Dataset: Kaggle Superstore (9,994 real transactions)
================================================================
"""

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import sqlite3, os

# ── PAGE CONFIG ──────────────────────────────────────────────
st.set_page_config(
    page_title="Retail Sales Intelligence Platform",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CUSTOM CSS ───────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap');
* { font-family: 'Inter', sans-serif; }

.main { background: #F5F7FA; }

.kpi-box {
    background: white;
    border-radius: 14px;
    padding: 18px 22px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.07);
    border-top: 4px solid #1565C0;
    margin-bottom: 10px;
    min-height: 100px;
}
.kpi-label { font-size:12px; color:#666; font-weight:600; letter-spacing:.5px; text-transform:uppercase; }
.kpi-val   { font-size:28px; font-weight:800; color:#1A1A2E; margin-top:4px; }
.kpi-sub   { font-size:11px; color:#888; margin-top:2px; }

.section-hdr {
    font-size:16px; font-weight:700; color:#1A1A2E;
    border-left:4px solid #1565C0; padding-left:10px;
    margin:20px 0 10px 0;
}

.insight-card {
    background:#E3F2FD; border-left:4px solid #1565C0;
    border-radius:8px; padding:12px 16px; margin:6px 0;
    font-size:13px; color:#1A237E;
}

.footer {
    text-align:center; padding:16px; color:#aaa;
    font-size:11px; border-top:1px solid #e0e0e0; margin-top:32px;
}
</style>
""", unsafe_allow_html=True)


# ── DATA LOADING ─────────────────────────────────────────────
@st.cache_data(show_spinner=False)
def load_data() -> pd.DataFrame:
    paths = ["data/superstore_bi.csv", "data/clean_superstore.csv",
             "data/superstore.csv", "superstore.csv"]
    for p in paths:
        if os.path.exists(p):
            df = pd.read_csv(p, encoding="latin-1",
                             parse_dates=["order_date"] if "order_date" in
                             pd.read_csv(p, nrows=1, encoding="latin-1").columns
                             else [])
            # normalise column names
            df.columns = (df.columns.str.strip().str.lower()
                           .str.replace(" ","_").str.replace("-","_"))
            if "order_date" in df.columns:
                df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
            if "order_year" not in df.columns and "order_date" in df.columns:
                df["order_year"]    = df["order_date"].dt.year
                df["order_month"]   = df["order_date"].dt.month
                df["month_name"]    = df["order_date"].dt.strftime("%B")
                df["quarter"]       = df["order_date"].dt.quarter
                df["quarter_label"] = "Q" + df["quarter"].astype(str)
            return df
    st.error("❌ No data file found. Please run data_cleaning.py first.")
    st.stop()


# ── HELPERS ──────────────────────────────────────────────────
def _fig(w=10, h=4): return plt.subplots(figsize=(w, h))
def _fmt_k(x, _):   return f"${x/1_000:.0f}K"
def _fmt_m(x, _):   return f"${x/1_000_000:.1f}M"

def kpi_card(col, label, value, sub="", color="#1565C0"):
    col.markdown(f"""
    <div class="kpi-box" style="border-top-color:{color}">
        <div class="kpi-label">{label}</div>
        <div class="kpi-val">{value}</div>
        <div class="kpi-sub">{sub}</div>
    </div>""", unsafe_allow_html=True)


# ── SIDEBAR FILTERS ──────────────────────────────────────────
def apply_filters(df: pd.DataFrame) -> pd.DataFrame:
    st.sidebar.markdown("## 🔎 Filters")

    regions    = ["All"] + sorted(df["region"].dropna().unique().tolist())
    categories = ["All"] + sorted(df["category"].dropna().unique().tolist())
    segments   = ["All"] + sorted(df["segment"].dropna().unique().tolist())
    years      = ["All"] + sorted(df["order_year"].dropna().unique().astype(int).tolist())

    r  = st.sidebar.selectbox("Region",   regions)
    c  = st.sidebar.selectbox("Category", categories)
    s  = st.sidebar.selectbox("Segment",  segments)
    y  = st.sidebar.selectbox("Year",     years)

    fdf = df.copy()
    if r != "All": fdf = fdf[fdf["region"]     == r]
    if c != "All": fdf = fdf[fdf["category"]   == c]
    if s != "All": fdf = fdf[fdf["segment"]    == s]
    if y != "All": fdf = fdf[fdf["order_year"] == int(y)]

    st.sidebar.markdown("---")
    st.sidebar.markdown(f"**Rows after filter:** `{len(fdf):,}`")
    st.sidebar.markdown(f"**Orders:** `{fdf['order_id'].nunique():,}`")
    return fdf


# ════════════════════════════════════════════════════════════
# TAB 1 — OVERVIEW
# ════════════════════════════════════════════════════════════
def tab_overview(df: pd.DataFrame):
    total_sales     = df["sales"].sum()
    total_profit    = df["profit"].sum()
    total_orders    = df["order_id"].nunique()
    total_customers = df["customer_id"].nunique()
    avg_order       = df.groupby("order_id")["sales"].sum().mean()
    margin          = total_profit / total_sales * 100 if total_sales else 0
    qty_sold        = df["quantity"].sum()

    c1,c2,c3,c4,c5,c6,c7 = st.columns(7)
    kpi_card(c1, "💰 Total Sales",     f"${total_sales/1e6:.2f}M",  "Gross revenue",      "#1565C0")
    kpi_card(c2, "📈 Total Profit",    f"${total_profit/1e3:.1f}K", "Net earnings",        "#2E7D32")
    kpi_card(c3, "🛒 Total Orders",    f"{total_orders:,}",          "Unique order IDs",   "#E65100")
    kpi_card(c4, "👥 Customers",       f"{total_customers:,}",       "Unique buyers",      "#6A1B9A")
    kpi_card(c5, "🎯 Avg Order",       f"${avg_order:,.0f}",         "Per order value",    "#00695C")
    kpi_card(c6, "📊 Profit Margin",   f"{margin:.1f}%",             "Net/Gross",          "#AD1457")
    kpi_card(c7, "📦 Units Sold",      f"{qty_sold:,}",              "Total quantity",     "#283593")

    st.markdown("---")

    col1, col2 = st.columns(2)

    # Region bar
    with col1:
        st.markdown('<div class="section-hdr">Sales by Region</div>', unsafe_allow_html=True)
        data = df.groupby("region")["sales"].sum().sort_values(ascending=False)
        fig, ax = _fig(6, 4)
        bars = ax.bar(data.index, data.values,
                      color=["#1565C0","#1976D2","#42A5F5","#90CAF9"], edgecolor="white")
        ax.bar_label(bars, fmt="$%.0f", padding=3, fontsize=8, fontweight="bold")
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
        ax.grid(axis="y", alpha=0.3); ax.spines[["top","right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    # Category pie
    with col2:
        st.markdown('<div class="section-hdr">Category Mix</div>', unsafe_allow_html=True)
        cat = df.groupby("category")["sales"].sum()
        fig, ax = _fig(6, 4)
        ax.pie(cat.values, labels=cat.index, autopct="%1.1f%%",
               colors=["#1565C0","#E65100","#2E7D32"],
               startangle=140, wedgeprops={"edgecolor":"white","linewidth":2})
        st.pyplot(fig); plt.close()

    # Monthly trend
    st.markdown('<div class="section-hdr">Monthly Sales & Profit Trend</div>',
                unsafe_allow_html=True)
    monthly = (df.groupby(df["order_date"].dt.to_period("M"))
                 .agg(Sales=("sales","sum"), Profit=("profit","sum")))
    idx = monthly.index.astype(str)
    fig, ax1 = _fig(14, 4)
    ax2 = ax1.twinx()
    ax1.plot(idx, monthly["Sales"],  color="#1565C0", lw=2.2, marker="o", ms=4, label="Sales")
    ax1.fill_between(idx, monthly["Sales"], alpha=0.1, color="#1565C0")
    ax2.plot(idx, monthly["Profit"], color="#2E7D32", lw=2, ls="--", marker="s", ms=3, label="Profit")
    ax1.set_ylabel("Sales ($)", color="#1565C0")
    ax2.set_ylabel("Profit ($)", color="#2E7D32")
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    plt.xticks(rotation=45, ha="right", fontsize=7)
    lines = ax1.get_lines() + ax2.get_lines()
    ax1.legend(lines, [l.get_label() for l in lines], loc="upper left")
    ax1.grid(alpha=0.3)
    st.pyplot(fig); plt.close()

    # Key insights
    st.markdown('<div class="section-hdr">💡 Key Business Insights</div>',
                unsafe_allow_html=True)
    top_r       = df.groupby("region")["sales"].sum().idxmax()
    top_c       = df.groupby("category")["profit"].sum().idxmax()
    loss        = (df["profit"] < 0).mean() * 100
    top_ship    = df.groupby("ship_mode")["order_id"].nunique().idxmax()
    ship_pct    = df.groupby("ship_mode")["order_id"].nunique()
    ship_share  = ship_pct.max() / ship_pct.sum() * 100
    top_seg     = df.groupby("segment")["sales"].sum().idxmax()
    seg_pct     = df.groupby("segment")["sales"].sum()
    seg_share   = seg_pct.max() / seg_pct.sum() * 100
    insights = [
        f"🏆 <b>{top_r}</b> region leads in total sales revenue.",
        f"💎 <b>{top_c}</b> is the most profitable category.",
        f"⚠️  <b>{loss:.1f}%</b> of all transactions are loss-making (high discount effect).",
        f"📦 <b>{top_ship}</b> is the dominant shipping mode ({ship_share:.0f}% of orders).",
        f"🎯 <b>{top_seg}</b> segment drives the highest revenue ({seg_share:.0f}% share).",
    ]
    for ins in insights:
        st.markdown(f'<div class="insight-card">{ins}</div>', unsafe_allow_html=True)


# ════════════════════════════════════════════════════════════
# TAB 2 — CATEGORY & PRODUCT
# ════════════════════════════════════════════════════════════
def tab_category(df: pd.DataFrame):
    # KPI strip
    cat_grp = (df.groupby("category")
                 .agg(Revenue=("sales","sum"), Profit=("profit","sum"),
                      Orders=("order_id","nunique"))
                 .reset_index())
    cols = st.columns(3)
    colors_map = {"Technology":"#1565C0","Furniture":"#E65100","Office Supplies":"#2E7D32"}
    for col, row in zip(cols, cat_grp.itertuples()):
        margin = row.Profit / row.Revenue * 100
        kpi_card(col, f"🏷️ {row.Category}",
                 f"${row.Revenue/1e3:.0f}K",
                 f"Profit: ${row.Profit/1e3:.0f}K  |  Margin: {margin:.1f}%",
                 colors_map.get(row.Category,"#1565C0"))

    st.markdown("---")
    col1, col2 = st.columns(2)

    # Sub-category profit waterfall
    with col1:
        st.markdown('<div class="section-hdr">Sub-Category Profit (Loss in Red)</div>',
                    unsafe_allow_html=True)
        data = (df.groupby("sub_category")["profit"].sum()
                  .sort_values(ascending=True))
        colors = ["#F44336" if v < 0 else "#43A047" for v in data.values]
        fig, ax = _fig(7, 6)
        ax.barh(data.index, data.values, color=colors, edgecolor="white")
        ax.axvline(0, color="black", lw=0.8)
        ax.set_title("Profit by Sub-Category", fontweight="bold")
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
        ax.grid(axis="x", alpha=0.3); ax.spines[["top","right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    # Category + Region heatmap
    with col2:
        st.markdown('<div class="section-hdr">Category × Region Heatmap (Sales $K)</div>',
                    unsafe_allow_html=True)
        pivot = df.pivot_table(values="sales", index="category",
                                columns="region", aggfunc="sum") / 1_000
        fig, ax = _fig(7, 6)
        im = ax.imshow(pivot.values, cmap="Blues", aspect="auto")
        ax.set_xticks(range(len(pivot.columns))); ax.set_xticklabels(pivot.columns)
        ax.set_yticks(range(len(pivot.index)));   ax.set_yticklabels(pivot.index)
        plt.colorbar(im, ax=ax, label="Sales ($K)")
        for i in range(len(pivot.index)):
            for j in range(len(pivot.columns)):
                ax.text(j, i, f"${pivot.values[i,j]:.0f}K",
                        ha="center", va="center", fontsize=9)
        st.pyplot(fig); plt.close()

    # Discount impact
    st.markdown('<div class="section-hdr">Discount Impact on Profit</div>',
                unsafe_allow_html=True)
    sample = df.sample(min(4000, len(df)), random_state=42)
    fig, ax = _fig(12, 4)
    cats   = sample["category"].unique()
    cmap   = {"Furniture":"#E65100","Office Supplies":"#1565C0","Technology":"#2E7D32"}
    for c in cats:
        sub = sample[sample["category"] == c]
        ax.scatter(sub["discount"], sub["profit"],
                   alpha=0.35, s=10, label=c, color=cmap.get(c,"grey"))
    ax.axhline(0, color="red", ls="--", lw=1, label="Break-even")
    ax.set_xlabel("Discount Rate"); ax.set_ylabel("Profit ($)")
    ax.set_title("Higher Discounts → More Losses", fontweight="bold")
    ax.legend(); ax.grid(alpha=0.3); ax.spines[["top","right"]].set_visible(False)
    st.pyplot(fig); plt.close()


# ════════════════════════════════════════════════════════════
# TAB 3 — GEOGRAPHY
# ════════════════════════════════════════════════════════════
def tab_geo(df: pd.DataFrame):
    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="section-hdr">Top 10 States by Revenue</div>',
                    unsafe_allow_html=True)
        data = (df.groupby("state")["sales"].sum()
                  .sort_values(ascending=True).tail(10))
        fig, ax = _fig(7, 5)
        ax.barh(data.index, data.values,
                color=plt.cm.Blues(np.linspace(0.4, 0.9, len(data))),
                edgecolor="white")
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
        ax.set_title("Top 10 States — Revenue", fontweight="bold")
        ax.grid(axis="x", alpha=0.3); ax.spines[["top","right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    with col2:
        st.markdown('<div class="section-hdr">Top 10 States by Profit</div>',
                    unsafe_allow_html=True)
        data = (df.groupby("state")["profit"].sum()
                  .sort_values(ascending=True).tail(10))
        colors = ["#F44336" if v < 0 else "#43A047" for v in data.values]
        fig, ax = _fig(7, 5)
        ax.barh(data.index, data.values, color=colors, edgecolor="white")
        ax.axvline(0, color="black", lw=0.8)
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
        ax.set_title("Top 10 States — Profit", fontweight="bold")
        ax.grid(axis="x", alpha=0.3); ax.spines[["top","right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    # Region grouped bar
    st.markdown('<div class="section-hdr">Region — Sales, Profit & Margin</div>',
                unsafe_allow_html=True)
    grp = (df.groupby("region")
             .agg(Sales=("sales","sum"), Profit=("profit","sum"))
             .reset_index())
    grp["Margin"] = grp["Profit"] / grp["Sales"] * 100
    x = np.arange(len(grp)); w = 0.35
    fig, ax1 = _fig(10, 4)
    ax2 = ax1.twinx()
    b1 = ax1.bar(x-w/2, grp["Sales"],  width=w, label="Sales",  color="#1565C0")
    b2 = ax1.bar(x+w/2, grp["Profit"], width=w, label="Profit", color="#43A047")
    ax2.plot(x, grp["Margin"], color="#E65100", lw=2.5, marker="D", ms=8, label="Margin %")
    ax1.set_xticks(x); ax1.set_xticklabels(grp["region"])
    ax1.set_ylabel("Amount ($)"); ax2.set_ylabel("Margin (%)")
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    lines  = [b1, b2] + ax2.get_lines()
    labels = ["Sales","Profit","Margin %"]
    ax1.legend(lines, labels, loc="upper left")
    ax1.grid(axis="y", alpha=0.3); ax1.spines[["top","right"]].set_visible(False)
    st.pyplot(fig); plt.close()

    # State table
    st.markdown('<div class="section-hdr">State-wise Summary Table</div>',
                unsafe_allow_html=True)
    state_tbl = (df.groupby(["state","region"])
                   .agg(Revenue=("sales","sum"), Profit=("profit","sum"),
                        Orders=("order_id","nunique"))
                   .reset_index()
                   .sort_values("Revenue", ascending=False))
    state_tbl["Margin%"] = (state_tbl["Profit"] / state_tbl["Revenue"] * 100).round(1)
    st.dataframe(
        state_tbl.style.format(
            {"Revenue":"${:,.0f}","Profit":"${:,.0f}","Margin%":"{:.1f}%"}),
        use_container_width=True, height=380)


# ════════════════════════════════════════════════════════════
# TAB 4 — CUSTOMERS & RFM
# ════════════════════════════════════════════════════════════
def tab_customers(df: pd.DataFrame):
    # RFM
    snapshot = df["order_date"].max()
    rfm = (df.groupby("customer_id")
             .agg(Name=("customer_name","first"),
                  Segment=("segment","first"),
                  Recency=("order_date", lambda x: (snapshot - x.max()).days),
                  Frequency=("order_id","nunique"),
                  Monetary=("sales","sum"))
             .reset_index())
    rfm["R"] = pd.qcut(rfm["Recency"],  4, labels=[4,3,2,1]).astype(int)
    rfm["F"] = pd.qcut(rfm["Frequency"].rank(method="first"),
                       4, labels=[1,2,3,4]).astype(int)
    rfm["M"] = pd.qcut(rfm["Monetary"], 4, labels=[1,2,3,4]).astype(int)
    rfm["Score"] = rfm["R"] + rfm["F"] + rfm["M"]
    rfm["Label"] = rfm["Score"].apply(
        lambda s: "Champions" if s>=10 else "Loyal" if s>=8 else "At Risk" if s>=6 else "Lost")

    seg_counts = rfm["Label"].value_counts()
    cmap = {"Champions":"#1565C0","Loyal":"#43A047","At Risk":"#FB8C00","Lost":"#E53935"}

    c1, c2, c3, c4 = st.columns(4)
    for col, (seg, cnt) in zip([c1,c2,c3,c4], seg_counts.items()):
        rev = rfm[rfm["Label"]==seg]["Monetary"].sum()
        kpi_card(col, f"👤 {seg}", str(cnt),
                 f"Revenue: ${rev/1e3:.0f}K", cmap.get(seg,"#1565C0"))

    col1, col2 = st.columns(2)
    with col1:
        st.markdown('<div class="section-hdr">RFM Segment Distribution</div>',
                    unsafe_allow_html=True)
        fig, ax = _fig(6, 4)
        ax.bar(seg_counts.index, seg_counts.values,
               color=[cmap.get(c,"grey") for c in seg_counts.index], edgecolor="white")
        for i,v in enumerate(seg_counts.values):
            ax.text(i, v+1, str(v), ha="center", fontweight="bold")
        ax.set_ylabel("Customers"); ax.grid(axis="y", alpha=0.3)
        ax.spines[["top","right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    with col2:
        st.markdown('<div class="section-hdr">Revenue by RFM Segment</div>',
                    unsafe_allow_html=True)
        mon = rfm.groupby("Label")["Monetary"].sum().sort_values(ascending=False)
        fig, ax = _fig(6, 4)
        ax.bar(mon.index, mon.values,
               color=[cmap.get(c,"grey") for c in mon.index], edgecolor="white")
        ax.set_ylabel("Revenue ($)")
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
        ax.grid(axis="y", alpha=0.3); ax.spines[["top","right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    # Top 10 customers
    st.markdown('<div class="section-hdr">Top 10 Customers by Revenue</div>',
                unsafe_allow_html=True)
    top10 = rfm.nlargest(10, "Monetary")
    fig, ax = _fig(12, 4)
    bars = ax.bar(top10["Name"], top10["Monetary"],
                  color=plt.cm.Blues(np.linspace(0.5, 0.9, 10)), edgecolor="white")
    ax.bar_label(bars, fmt="$%.0f", padding=3, fontsize=8, fontweight="bold")
    plt.xticks(rotation=40, ha="right", fontsize=8)
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax.grid(axis="y", alpha=0.3); ax.spines[["top","right"]].set_visible(False)
    st.pyplot(fig); plt.close()

    # RFM table
    st.markdown('<div class="section-hdr">Full RFM Table</div>', unsafe_allow_html=True)
    st.dataframe(
        rfm[["Name","Segment","Recency","Frequency","Monetary","Label"]]
          .sort_values("Monetary", ascending=False)
          .reset_index(drop=True)
          .style.format({"Monetary":"${:,.0f}"}),
        use_container_width=True, height=380)


# ════════════════════════════════════════════════════════════
# TAB 5 — DATA EXPLORER
# ════════════════════════════════════════════════════════════
def tab_data(df: pd.DataFrame):
    st.markdown('<div class="section-hdr">Dataset Explorer</div>', unsafe_allow_html=True)

    show_cols = st.multiselect(
        "Select columns",
        df.columns.tolist(),
        default=["order_id","customer_name","state","region","category",
                 "sub_category","sales","profit","discount","quantity","order_date"])

    n = st.slider("Rows to display", 50, min(5000, len(df)), 200, step=50)

    st.dataframe(
        df[show_cols].head(n)
          .style.format({c: "${:,.2f}" for c in ["sales","profit"]
                         if c in show_cols}),
        use_container_width=True, height=420)

    col1, col2 = st.columns(2)
    with col1:
        csv = df.to_csv(index=False).encode("utf-8")
        st.download_button("⬇️ Download Full Dataset (CSV)", csv,
                           "superstore_data.csv", "text/csv")
    with col2:
        for p in ["reports/executive_report.csv","executive_report.csv"]:
            if os.path.exists(p):
                with open(p) as f:
                    st.download_button("⬇️ Download Executive Report (CSV)",
                                       f.read(), "executive_report.csv", "text/csv")
                break


# ════════════════════════════════════════════════════════════
# TAB 6 — ANOMALY DETECTION
# ════════════════════════════════════════════════════════════
def tab_anomaly(df: pd.DataFrame):
    st.markdown("""
    <div style="background:linear-gradient(135deg,#1A0A0A,#B71C1C);
                padding:16px 22px;border-radius:10px;margin-bottom:18px">
        <h3 style="color:white;margin:0;font-size:17px;font-weight:700">
            🔍 Anomaly Detection — Isolation Forest + Business Rules
        </h3>
        <p style="color:#FFCDD2;margin:4px 0 0 0;font-size:12px">
            Scikit-learn IsolationForest · Loss Products · High-Discount Orders · Problem States
        </p>
    </div>
    """, unsafe_allow_html=True)

    from sklearn.ensemble import IsolationForest
    from sklearn.preprocessing import StandardScaler
    import warnings; warnings.filterwarnings("ignore")

    # ── Transaction anomalies ──
    with st.spinner("Running Isolation Forest…"):
        features = ["sales", "profit", "discount", "quantity", "profit_margin_pct"] \
                   if "profit_margin_pct" in df.columns else \
                   ["sales", "profit", "discount", "quantity"]
        X = df[features].fillna(0)
        X_scaled = StandardScaler().fit_transform(X)
        iso = IsolationForest(n_estimators=200, contamination=0.05,
                              random_state=42, n_jobs=-1)
        preds  = iso.fit_predict(X_scaled)
        scores = iso.decision_function(X_scaled)

    df_a = df.copy()
    df_a["anomaly_flag"]  = (preds == -1).astype(int)
    df_a["anomaly_score"] = scores.round(4)
    n_anom = df_a["anomaly_flag"].sum()

    # KPI strip
    loss_orders  = (df["profit"] < 0).sum()
    heavy_disc   = (df["discount"] >= 0.40).sum()
    loss_revenue = df[df["profit"] < 0]["profit"].sum()

    c1, c2, c3, c4 = st.columns(4)
    kpi_card(c1, "🔴 Flagged Transactions", f"{n_anom:,}",
             f"{n_anom/max(len(df),1)*100:.1f}% of orders", "#B71C1C")
    kpi_card(c2, "📉 Loss-Making Orders",   f"{loss_orders:,}",
             f"{loss_orders/max(len(df),1)*100:.1f}% of orders", "#E65100")
    kpi_card(c3, "🏷️ Heavy Discount (≥40%)", f"{heavy_disc:,}",
             "Almost always unprofitable", "#AD1457")
    kpi_card(c4, "💸 Total Loss Amount",    f"${abs(loss_revenue)/1e3:.1f}K",
             "From loss-making transactions", "#6A1B9A")

    st.markdown("---")
    col1, col2 = st.columns(2)

    # Scatter: anomalies
    with col1:
        st.markdown('<div class="section-hdr">Transaction Anomaly Map</div>',
                    unsafe_allow_html=True)
        sample = df_a.sample(min(4000, len(df_a)), random_state=42)
        normal = sample[sample["anomaly_flag"] == 0]
        anom   = sample[sample["anomaly_flag"] == 1]
        fig, ax = _fig(6, 4)
        ax.scatter(normal["sales"], normal["profit"],
                   alpha=0.2, s=8, color="#1565C0", label="Normal")
        ax.scatter(anom["sales"], anom["profit"],
                   alpha=0.75, s=20, color="#E53935",
                   label=f"Anomaly ({len(anom):,})", marker="X", zorder=5)
        ax.axhline(0, color="black", lw=0.8, ls="--")
        ax.set_xlabel("Sales ($)"); ax.set_ylabel("Profit ($)")
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
        ax.legend(fontsize=8); ax.grid(alpha=0.25)
        ax.spines[["top", "right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    # Sub-category profit flags
    with col2:
        st.markdown('<div class="section-hdr">Sub-Category Profit Flags</div>',
                    unsafe_allow_html=True)
        prod = (df.groupby("sub_category")
                  .agg(Revenue=("sales","sum"), Profit=("profit","sum"),
                       Avg_Disc=("discount","mean"))
                  .reset_index()
                  .sort_values("Profit"))
        prod["issue"] = "OK"
        prod.loc[(prod["Profit"] < 0) & (prod["Revenue"] > 50_000), "issue"] = "High Rev, Loss"
        prod.loc[(prod["Profit"] < 0) & (prod["Avg_Disc"] > 0.25),  "issue"] = "Discount Loss"
        prod.loc[(prod["Profit"] < 0), "issue"]                              = "Loss"
        color_map = {"High Rev, Loss":"#E53935","Discount Loss":"#FB8C00",
                     "Loss":"#FF7043","OK":"#90CAF9"}
        colors = [color_map.get(i, "#90CAF9") for i in prod["issue"]]
        fig, ax = _fig(6, 4)
        ax.barh(prod["sub_category"], prod["Profit"], color=colors, edgecolor="white")
        ax.axvline(0, color="black", lw=0.8)
        ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x/1e3:.0f}K"))
        ax.grid(axis="x", alpha=0.3)
        ax.spines[["top", "right"]].set_visible(False)
        from matplotlib.patches import Patch
        ax.legend(handles=[Patch(facecolor=v, label=k)
                            for k, v in color_map.items()], fontsize=7, loc="lower right")
        st.pyplot(fig); plt.close()

    # Loss states
    st.markdown('<div class="section-hdr">Loss-Making States — Revenue vs Profit</div>',
                unsafe_allow_html=True)
    state_p = (df.groupby(["state","region"])
                 .agg(Revenue=("sales","sum"), Profit=("profit","sum"))
                 .reset_index())
    state_p["Margin%"] = (state_p["Profit"] / state_p["Revenue"] * 100).round(1)
    loss_states = state_p[state_p["Profit"] < 0].sort_values("Profit")
    if len(loss_states):
        fig, ax = _fig(12, 3.5)
        x  = np.arange(len(loss_states)); w = 0.35
        ax.bar(x - w/2, loss_states["Revenue"], width=w, label="Revenue", color="#1565C0")
        ax.bar(x + w/2, loss_states["Profit"],  width=w, label="Profit",  color="#E53935")
        ax.axhline(0, color="black", lw=0.6)
        ax.set_xticks(x); ax.set_xticklabels(loss_states["state"], rotation=45, ha="right")
        ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x/1e3:.0f}K"))
        ax.legend(); ax.grid(axis="y", alpha=0.3)
        ax.spines[["top","right"]].set_visible(False)
        st.pyplot(fig); plt.close()
    else:
        st.info("No loss-making states in current filter selection.")

    # Flagged transaction table
    st.markdown('<div class="section-hdr">Top Flagged Transactions (by Anomaly Score)</div>',
                unsafe_allow_html=True)
    show_cols = ["customer_name","category","sub_category","state",
                 "sales","profit","discount","anomaly_score"]
    show_cols = [c for c in show_cols if c in df_a.columns]
    flagged_tbl = (df_a[df_a["anomaly_flag"] == 1][show_cols]
                   .sort_values("anomaly_score")
                   .head(50)
                   .reset_index(drop=True))
    st.dataframe(
        flagged_tbl.style.format(
            {c: "${:,.2f}" for c in ["sales","profit"] if c in flagged_tbl.columns}),
        use_container_width=True, height=320)

    csv = flagged_tbl.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download Flagged Transactions", csv,
                       "anomaly_transactions.csv", "text/csv")


# ════════════════════════════════════════════════════════════
# TAB 7 — FORECASTING (Prophet)
# ════════════════════════════════════════════════════════════
def tab_forecasting(df: pd.DataFrame):
    st.markdown("""
    <div style="background:linear-gradient(135deg,#0D1B2A,#1565C0);
                padding:16px 22px;border-radius:10px;margin-bottom:18px">
        <h3 style="color:white;margin:0;font-size:17px;font-weight:700">
            📈 Sales Forecasting — Next 90 Days (Prophet)
        </h3>
        <p style="color:#90CAF9;margin:4px 0 0 0;font-size:12px">
            Facebook Prophet · Multiplicative Seasonality · 95% Confidence Interval
        </p>
    </div>
    """, unsafe_allow_html=True)

    try:
        from prophet import Prophet
        prophet_available = True
    except ImportError:
        prophet_available = False

    if not prophet_available:
        st.error("⚠️ Prophet not installed. Run: `pip install prophet`")
        return

    import warnings
    warnings.filterwarnings("ignore")

    # Build daily series from filtered data
    daily = (df.groupby("order_date")
               .agg(sales=("sales", "sum"), profit=("profit", "sum"))
               .reset_index()
               .rename(columns={"order_date": "ds", "sales": "y"})
               .sort_values("ds"))

    if len(daily) < 60:
        st.warning("⚠️ Not enough data points for forecasting. Remove filters or select a wider date range.")
        return

    with st.spinner("Running Prophet forecast… (30–60 seconds)"):
        model = Prophet(
            yearly_seasonality=True,
            weekly_seasonality=True,
            daily_seasonality=False,
            seasonality_mode="multiplicative",
            changepoint_prior_scale=0.05,
        )
        model.fit(daily[["ds", "y"]])
        future   = model.make_future_dataframe(periods=90, freq="D")
        forecast = model.predict(future)

    last_date = daily["ds"].max()
    fut       = forecast[forecast["ds"] > last_date]

    # ── KPI Cards ──
    total_f  = fut["yhat"].sum()
    avg_d    = fut["yhat"].mean()
    peak_day = fut.loc[fut["yhat"].idxmax(), "ds"].strftime("%d %b %Y")
    peak_val = fut["yhat"].max()
    low_90   = fut["yhat_lower"].sum()
    high_90  = fut["yhat_upper"].sum()

    c1, c2, c3, c4 = st.columns(4)
    kpi_card(c1, "🔮 Forecast Total (90d)", f"${total_f/1e3:.1f}K", "Predicted revenue", "#1565C0")
    kpi_card(c2, "📅 Avg Daily Sales",      f"${avg_d:,.0f}",        "Next 90 days avg",  "#2E7D32")
    kpi_card(c3, "🏆 Peak Forecast Day",    peak_day,                f"${peak_val:,.0f}", "#E65100")
    kpi_card(c4, "📊 95% CI Range",         f"${low_90/1e3:.0f}K – ${high_90/1e3:.0f}K",
             "Confidence band", "#6A1B9A")

    st.markdown("---")

    # ── Main Forecast Chart ──
    st.markdown('<div class="section-hdr">Sales Forecast — Actual vs Predicted</div>',
                unsafe_allow_html=True)

    hist = forecast[forecast["ds"] <= last_date]

    fig, ax = _fig(14, 5)
    ax.plot(daily["ds"], daily["y"], color="#1565C0", lw=1.8,
            label="Actual Sales", zorder=3)
    ax.plot(hist["ds"], hist["yhat"], color="#42A5F5", lw=1.2,
            ls="--", label="Model Fit", alpha=0.6)
    ax.plot(fut["ds"], fut["yhat"], color="#E65100", lw=2.3,
            label="Forecast (90 days)", zorder=4)
    ax.fill_between(fut["ds"], fut["yhat_lower"], fut["yhat_upper"],
                    alpha=0.18, color="#E65100", label="95% Confidence Band")
    ax.axvline(last_date, color="gray", ls=":", lw=1.5, label="Forecast Start")
    ax.set_ylabel("Daily Sales ($)"); ax.set_xlabel("Date")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.legend(loc="upper left", fontsize=9)
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)
    st.pyplot(fig); plt.close()

    # ── Seasonality Charts ──
    col1, col2 = st.columns(2)

    with col1:
        st.markdown('<div class="section-hdr">Weekly Seasonality Pattern</div>',
                    unsafe_allow_html=True)
        days  = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
        dates = pd.date_range("2024-01-01", periods=7)
        tmp   = pd.DataFrame({"ds": dates})
        comp  = model.predict(tmp)
        weekly_effect = comp["weekly"].values
        colors = ["#43A047" if v >= 0 else "#E53935" for v in weekly_effect]
        fig, ax = _fig(6, 3.5)
        ax.bar(days, weekly_effect, color=colors, edgecolor="white")
        ax.axhline(0, color="black", lw=0.8)
        ax.set_title("Day-of-Week Effect on Sales", fontweight="bold")
        ax.set_ylabel("Seasonality Effect")
        plt.xticks(rotation=30, ha="right", fontsize=9)
        ax.grid(axis="y", alpha=0.3)
        ax.spines[["top", "right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    with col2:
        st.markdown('<div class="section-hdr">Yearly Seasonality Pattern</div>',
                    unsafe_allow_html=True)
        months = pd.date_range("2024-01-01", periods=12, freq="MS")
        tmp2   = pd.DataFrame({"ds": months})
        comp2  = model.predict(tmp2)
        month_names = [m.strftime("%b") for m in months]
        fig, ax = _fig(6, 3.5)
        ax.plot(month_names, comp2["yearly"].values,
                color="#1565C0", lw=2.2, marker="o", ms=6)
        ax.fill_between(range(12), comp2["yearly"].values,
                        alpha=0.12, color="#1565C0")
        ax.set_title("Month-of-Year Effect on Sales", fontweight="bold")
        ax.set_ylabel("Seasonality Effect")
        ax.grid(alpha=0.3)
        ax.spines[["top", "right"]].set_visible(False)
        st.pyplot(fig); plt.close()

    # ── Forecast Table ──
    st.markdown('<div class="section-hdr">Forecast Data — Next 90 Days</div>',
                unsafe_allow_html=True)
    tbl = fut[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
    tbl.columns = ["Date", "Forecast ($)", "Lower Bound ($)", "Upper Bound ($)"]
    tbl["Date"] = tbl["Date"].dt.strftime("%Y-%m-%d")
    for c in ["Forecast ($)", "Lower Bound ($)", "Upper Bound ($)"]:
        tbl[c] = tbl[c].round(2)
    st.dataframe(tbl.reset_index(drop=True), use_container_width=True, height=320)

    # Download
    csv = tbl.to_csv(index=False).encode("utf-8")
    st.download_button("⬇️ Download Forecast CSV", csv, "sales_forecast_90d.csv", "text/csv")


# ════════════════════════════════════════════════════════════
# MAIN
# ════════════════════════════════════════════════════════════
def main():
    # Header
    st.markdown("""
    <div style="background:linear-gradient(135deg,#0D1B2A,#1565C0);
                padding:26px 34px;border-radius:14px;margin-bottom:24px">
        <h1 style="color:white;margin:0;font-size:26px;font-weight:800">
            📊 Retail Sales Intelligence Platform
        </h1>
        <p style="color:#90CAF9;margin:6px 0 0 0;font-size:13px">
            Kaggle Superstore Dataset  ·  9,994 Real Transactions  ·  4 Regions  ·  49 States
        </p>
    </div>
    """, unsafe_allow_html=True)

    with st.spinner("Loading data …"):
        df_full = load_data()

    df = apply_filters(df_full)

    tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
        "📊 Overview",
        "🏷️ Category & Products",
        "🗺️ Geography",
        "👥 Customers & RFM",
        "🔍 Data Explorer",
        "🚨 Anomaly Detection",
        "📈 Forecasting",
    ])
    with tab1: tab_overview(df)
    with tab2: tab_category(df)
    with tab3: tab_geo(df)
    with tab4: tab_customers(df)
    with tab5: tab_data(df)
    with tab6: tab_anomaly(df)
    with tab7: tab_forecasting(df)

    st.markdown("""
    <div class="footer">
        Retail Sales Intelligence Platform  ·  Kaggle Superstore Dataset
        ·  Built with Python · Pandas · Matplotlib · Streamlit
    </div>""", unsafe_allow_html=True)


if __name__ == "__main__":
    main()
