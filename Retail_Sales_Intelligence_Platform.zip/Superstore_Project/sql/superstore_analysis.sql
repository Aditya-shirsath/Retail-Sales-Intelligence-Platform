-- ================================================================
--  Retail Sales Intelligence Platform
--  Dataset : Kaggle Sample Superstore (9,994 real transactions)
--  Database: retail_sales.db  |  Table: sales
--  Author  : Data Analytics Engineer
-- ================================================================


-- ── 1. BUSINESS SUMMARY KPIs ──────────────────────────────────
SELECT
    ROUND(SUM(sales),  2)                         AS Total_Sales,
    ROUND(SUM(profit), 2)                         AS Total_Profit,
    COUNT(DISTINCT order_id)                      AS Total_Orders,
    COUNT(DISTINCT customer_id)                   AS Total_Customers,
    ROUND(AVG(sales),  2)                         AS Avg_Order_Value,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Profit_Margin_Pct
FROM sales;


-- ── 2. REGION-WISE ANALYSIS ───────────────────────────────────
SELECT
    region,
    ROUND(SUM(sales),  2)                         AS Total_Sales,
    ROUND(SUM(profit), 2)                         AS Total_Profit,
    COUNT(DISTINCT order_id)                      AS Total_Orders,
    COUNT(DISTINCT customer_id)                   AS Customers,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Profit_Margin_Pct
FROM   sales
GROUP  BY region
ORDER  BY Total_Sales DESC;


-- ── 3. CATEGORY-WISE ANALYSIS ─────────────────────────────────
SELECT
    category,
    COUNT(*)                                      AS Rows,
    COUNT(DISTINCT order_id)                      AS Orders,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit,
    ROUND(AVG(sales),  2)                         AS Avg_Sale,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Margin_Pct
FROM   sales
GROUP  BY category
ORDER  BY Revenue DESC;


-- ── 4. SUB-CATEGORY PROFIT RANKING ────────────────────────────
SELECT
    sub_category,
    category,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Margin_Pct,
    CASE WHEN SUM(profit) < 0 THEN 'LOSS' ELSE 'PROFIT' END AS Status
FROM   sales
GROUP  BY sub_category
ORDER  BY Profit DESC;


-- ── 5. TOP 10 CUSTOMERS BY REVENUE ────────────────────────────
SELECT
    customer_name,
    customer_id,
    segment,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit,
    COUNT(DISTINCT order_id)                      AS Orders,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Margin_Pct
FROM   sales
GROUP  BY customer_id
ORDER  BY Revenue DESC
LIMIT  10;


-- ── 6. TOP 10 STATES BY REVENUE ───────────────────────────────
SELECT
    state,
    region,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit,
    COUNT(DISTINCT order_id)                      AS Orders,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Margin_Pct
FROM   sales
GROUP  BY state
ORDER  BY Revenue DESC
LIMIT  10;


-- ── 7. BOTTOM 10 STATES BY PROFIT (LOSS STATES) ───────────────
SELECT
    state,
    region,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit
FROM   sales
GROUP  BY state
ORDER  BY Profit ASC
LIMIT  10;


-- ── 8. SEGMENT ANALYSIS ───────────────────────────────────────
SELECT
    segment,
    COUNT(DISTINCT customer_id)                   AS Customers,
    COUNT(DISTINCT order_id)                      AS Orders,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Margin_Pct
FROM   sales
GROUP  BY segment
ORDER  BY Revenue DESC;


-- ── 9. SHIP MODE PERFORMANCE ──────────────────────────────────
SELECT
    ship_mode,
    COUNT(*)                                      AS Total_Rows,
    COUNT(DISTINCT order_id)                      AS Orders,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit,
    ROUND(AVG(ship_days), 1)                      AS Avg_Ship_Days
FROM   sales
GROUP  BY ship_mode
ORDER  BY Revenue DESC;


-- ── 10. MONTHLY SALES TREND ───────────────────────────────────
SELECT
    STRFTIME('%Y-%m', order_date)                 AS Month,
    ROUND(SUM(sales),  2)                         AS Monthly_Sales,
    ROUND(SUM(profit), 2)                         AS Monthly_Profit,
    COUNT(DISTINCT order_id)                      AS Orders,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Margin_Pct
FROM   sales
GROUP  BY STRFTIME('%Y-%m', order_date)
ORDER  BY Month;


-- ── 11. QUARTERLY GROWTH ──────────────────────────────────────
SELECT
    order_year                                    AS Year,
    quarter_label                                 AS Quarter,
    ROUND(SUM(sales),  2)                         AS Sales,
    ROUND(SUM(profit), 2)                         AS Profit,
    COUNT(DISTINCT order_id)                      AS Orders
FROM   sales
GROUP  BY order_year, quarter_label
ORDER  BY order_year, quarter_label;


-- ── 12. DISCOUNT IMPACT ANALYSIS ─────────────────────────────
SELECT
    CASE
        WHEN discount = 0          THEN '0% — No Discount'
        WHEN discount <= 0.10      THEN '1–10%'
        WHEN discount <= 0.20      THEN '11–20%'
        WHEN discount <= 0.40      THEN '21–40%'
        ELSE                            '40%+ Heavy Discount'
    END                                           AS Discount_Band,
    COUNT(*)                                      AS Orders,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit,
    ROUND(AVG(profit), 2)                         AS Avg_Profit_Per_Row
FROM   sales
GROUP  BY Discount_Band
ORDER  BY Discount_Band;


-- ── 13. LOSS-MAKING PRODUCTS (Top 15) ────────────────────────
SELECT
    product_name,
    category,
    sub_category,
    COUNT(*)                                      AS Times_Sold,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Total_Loss
FROM   sales
GROUP  BY product_name
HAVING SUM(profit) < 0
ORDER  BY Total_Loss ASC
LIMIT  15;


-- ── 14. CATEGORY × REGION CROSS ANALYSIS ─────────────────────
SELECT
    category,
    region,
    ROUND(SUM(sales),  2)                         AS Revenue,
    ROUND(SUM(profit), 2)                         AS Profit,
    COUNT(DISTINCT order_id)                      AS Orders,
    ROUND(SUM(profit) / SUM(sales) * 100, 2)      AS Margin_Pct
FROM   sales
GROUP  BY category, region
ORDER  BY category, Revenue DESC;


-- ── 15. CUSTOMER RFM BASE TABLE ───────────────────────────────
SELECT
    customer_id,
    customer_name,
    segment,
    JULIANDAY(MAX(order_date)) - JULIANDAY(
        (SELECT MAX(order_date) FROM sales))      AS Recency_Days,
    COUNT(DISTINCT order_id)                      AS Frequency,
    ROUND(SUM(sales), 2)                          AS Monetary,
    CASE
        WHEN SUM(sales) > 10000 THEN 'High Value'
        WHEN SUM(sales) >  5000 THEN 'Mid Value'
        ELSE                         'Low Value'
    END                                           AS Value_Tier
FROM   sales
GROUP  BY customer_id
ORDER  BY Monetary DESC;


-- ── 16. YOY GROWTH ────────────────────────────────────────────
SELECT
    a.order_year                                  AS Year,
    ROUND(a.Sales, 2)                             AS Sales,
    ROUND(a.Profit, 2)                            AS Profit,
    ROUND((a.Sales - b.Sales) / b.Sales * 100, 2) AS Sales_Growth_Pct,
    ROUND((a.Profit- b.Profit)/ b.Profit* 100, 2) AS Profit_Growth_Pct
FROM (
    SELECT order_year, SUM(sales) AS Sales, SUM(profit) AS Profit
    FROM   sales GROUP BY order_year
) a
LEFT JOIN (
    SELECT order_year, SUM(sales) AS Sales, SUM(profit) AS Profit
    FROM   sales GROUP BY order_year
) b ON a.order_year = b.order_year + 1
ORDER BY a.order_year;
