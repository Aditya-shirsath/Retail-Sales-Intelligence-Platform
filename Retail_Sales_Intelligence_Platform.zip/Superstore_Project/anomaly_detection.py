"""
================================================================
  Retail Sales Intelligence Platform
  Module : anomaly_detection.py
  Purpose: Detect anomalous products, states & orders using
           Isolation Forest + rule-based business logic
  Run    : python anomaly_detection.py
================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import os, warnings
warnings.filterwarnings("ignore")

CHART_DIR  = "reports/charts"
REPORT_DIR = "reports"


# ── LOAD ─────────────────────────────────────────────────────
def load_data() -> pd.DataFrame:
    paths = ["data/superstore_bi.csv", "data/clean_superstore.csv", "data/superstore.csv"]
    for p in paths:
        if os.path.exists(p):
            df = pd.read_csv(p, encoding="latin-1")
            df.columns = (df.columns.str.strip().str.lower()
                          .str.replace(" ", "_").str.replace("-", "_"))
            df["order_date"] = pd.to_datetime(df["order_date"], errors="coerce")
            if "profit_margin_pct" not in df.columns:
                df["profit_margin_pct"] = (df["profit"] / df["sales"] * 100).round(2)
            if "ship_days" not in df.columns and "ship_date" in df.columns:
                df["ship_date"] = pd.to_datetime(df["ship_date"], errors="coerce")
                df["ship_days"] = (df["ship_date"] - df["order_date"]).dt.days
            print(f"[✓] Loaded  →  {p}  ({len(df):,} rows)")
            return df
    raise FileNotFoundError("No data file found. Run data_cleaning.py first.")


# ── 1. TRANSACTION-LEVEL ANOMALIES (Isolation Forest) ────────
def detect_transaction_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    """
    Flag individual transactions that are statistically unusual
    based on Sales, Profit, Discount, Quantity, Profit Margin.
    """
    features = ["sales", "profit", "discount", "quantity", "profit_margin_pct"]
    df_feat = df[features].fillna(0)

    scaler   = StandardScaler()
    X_scaled = scaler.fit_transform(df_feat)

    iso = IsolationForest(
        n_estimators=200,
        contamination=0.05,   # expect ~5% anomalies
        random_state=42,
        n_jobs=-1
    )
    preds  = iso.fit_predict(X_scaled)
    scores = iso.decision_function(X_scaled)

    df = df.copy()
    df["anomaly_flag"]  = (preds == -1).astype(int)
    df["anomaly_score"] = scores.round(4)   # lower = more anomalous

    n = df["anomaly_flag"].sum()
    print(f"[✓] Transaction anomalies detected  →  {n:,} flagged ({n/len(df)*100:.1f}%)")
    return df


# ── 2. PRODUCT / SUB-CATEGORY ANOMALIES (Rule-Based) ─────────
def detect_product_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    """
    Products with high revenue but negative profit = pricing anomaly.
    Products with discount > 30% and negative profit = discount anomaly.
    """
    prod = (df.groupby("sub_category")
              .agg(Revenue=("sales", "sum"),
                   Profit=("profit", "sum"),
                   Orders=("order_id", "nunique"),
                   Avg_Discount=("discount", "mean"),
                   Avg_Margin=("profit_margin_pct", "mean"))
              .reset_index())
    prod["Avg_Discount_Pct"] = (prod["Avg_Discount"] * 100).round(1)
    prod["Margin_Pct"]       = (prod["Profit"] / prod["Revenue"] * 100).round(2)

    prod["issue"] = "OK"
    prod.loc[(prod["Profit"] < 0) & (prod["Revenue"] > 50_000),
             "issue"] = "🔴 High Revenue, Negative Profit"
    prod.loc[(prod["Profit"] < 0) & (prod["Avg_Discount_Pct"] > 25),
             "issue"] = "🟠 Heavy Discount → Loss"
    prod.loc[(prod["Margin_Pct"] < 5) & (prod["Margin_Pct"] >= 0),
             "issue"] = "🟡 Near Break-Even"
    prod.loc[prod["Margin_Pct"] > 30, "issue"] = "🟢 High Margin Star"

    anomalies = prod[prod["issue"].str.startswith(("🔴", "🟠"))].copy()
    print(f"[✓] Product anomalies  →  {len(anomalies)} sub-categories flagged")
    return prod, anomalies


# ── 3. STATE-LEVEL ANOMALIES ──────────────────────────────────
def detect_state_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    """States with high revenue but negative or very low profit."""
    state = (df.groupby(["state", "region"])
               .agg(Revenue=("sales", "sum"),
                    Profit=("profit", "sum"),
                    Orders=("order_id", "nunique"))
               .reset_index())
    state["Margin_Pct"] = (state["Profit"] / state["Revenue"] * 100).round(2)
    state["issue"] = "Normal"
    state.loc[(state["Profit"] < 0),
              "issue"] = "🔴 Loss State"
    state.loc[(state["Margin_Pct"] < 3) & (state["Margin_Pct"] >= 0),
              "issue"] = "🟠 Near Break-Even"
    state.loc[state["Margin_Pct"] > 20, "issue"] = "🟢 High Margin"

    flagged = state[state["issue"].str.startswith(("🔴", "🟠"))].copy()
    print(f"[✓] State anomalies  →  {len(flagged)} states flagged")
    return state, flagged


# ── 4. DISCOUNT ANOMALIES ─────────────────────────────────────
def detect_discount_anomalies(df: pd.DataFrame) -> pd.DataFrame:
    """Orders with discount > 40% — almost always loss-making."""
    flagged = df[df["discount"] >= 0.40].copy()
    flagged["loss_amount"] = flagged["profit"].clip(upper=0)
    print(f"[✓] High-discount orders (≥40%)  →  {len(flagged):,} orders flagged")
    return flagged


# ── CHARTS ────────────────────────────────────────────────────
def plot_anomaly_scatter(df_flagged: pd.DataFrame):
    """Scatter: Sales vs Profit coloured by anomaly flag."""
    os.makedirs(CHART_DIR, exist_ok=True)
    sample = df_flagged.sample(min(5000, len(df_flagged)), random_state=42)
    normal = sample[sample["anomaly_flag"] == 0]
    anom   = sample[sample["anomaly_flag"] == 1]

    fig, ax = plt.subplots(figsize=(11, 5))
    fig.patch.set_facecolor("#F5F7FA"); ax.set_facecolor("#F5F7FA")
    ax.scatter(normal["sales"], normal["profit"],
               alpha=0.25, s=8, color="#1565C0", label="Normal")
    ax.scatter(anom["sales"], anom["profit"],
               alpha=0.7,  s=18, color="#E53935", label=f"Anomaly ({len(anom):,})",
               marker="X", zorder=5)
    ax.axhline(0, color="black", lw=0.8, ls="--")
    ax.set_title("Transaction Anomaly Detection — Isolation Forest",
                 fontsize=13, fontweight="bold", color="#1A1A2E")
    ax.set_xlabel("Sales ($)"); ax.set_ylabel("Profit ($)")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.legend(); ax.grid(alpha=0.25)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    path = f"{CHART_DIR}/09_anomaly_scatter.png"
    plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
    print(f"[✓] Saved  →  {path}")


def plot_product_flags(prod_df: pd.DataFrame):
    """Horizontal bar — sub-category profit coloured by issue type."""
    os.makedirs(CHART_DIR, exist_ok=True)
    data = prod_df.sort_values("Profit")
    color_map = {
        "🔴 High Revenue, Negative Profit": "#E53935",
        "🟠 Heavy Discount → Loss":         "#FB8C00",
        "🟡 Near Break-Even":               "#FDD835",
        "🟢 High Margin Star":              "#43A047",
        "OK":                               "#90CAF9",
    }
    colors = [color_map.get(i, "#90CAF9") for i in data["issue"]]

    fig, ax = plt.subplots(figsize=(10, 7))
    fig.patch.set_facecolor("#F5F7FA"); ax.set_facecolor("#F5F7FA")
    ax.barh(data["sub_category"], data["Profit"], color=colors, edgecolor="white")
    ax.axvline(0, color="black", lw=0.8)
    ax.set_title("Sub-Category Profit — Anomaly Flags",
                 fontsize=13, fontweight="bold", color="#1A1A2E")
    ax.set_xlabel("Total Profit ($)")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x/1e3:.0f}K"))
    ax.grid(axis="x", alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)

    # Legend
    from matplotlib.patches import Patch
    legend_els = [Patch(facecolor=v, label=k) for k, v in color_map.items() if k != "OK"]
    ax.legend(handles=legend_els, loc="lower right", fontsize=8)

    plt.tight_layout()
    path = f"{CHART_DIR}/10_product_flags.png"
    plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
    print(f"[✓] Saved  →  {path}")


def plot_discount_loss(df_high_discount: pd.DataFrame):
    """Bar — total loss amount by category for high-discount orders."""
    os.makedirs(CHART_DIR, exist_ok=True)
    loss_by_cat = (df_high_discount.groupby("category")["profit"]
                   .sum().sort_values())
    colors = ["#E53935" if v < 0 else "#43A047" for v in loss_by_cat.values]

    fig, ax = plt.subplots(figsize=(8, 4))
    fig.patch.set_facecolor("#F5F7FA"); ax.set_facecolor("#F5F7FA")
    ax.barh(loss_by_cat.index, loss_by_cat.values, color=colors, edgecolor="white")
    ax.axvline(0, color="black", lw=0.8)
    ax.set_title("Profit from Orders with Discount ≥ 40%",
                 fontsize=12, fontweight="bold", color="#1A1A2E")
    ax.set_xlabel("Total Profit ($)")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(lambda x, _: f"${x:,.0f}"))
    ax.grid(axis="x", alpha=0.3)
    ax.spines[["top", "right"]].set_visible(False)
    plt.tight_layout()
    path = f"{CHART_DIR}/11_discount_loss.png"
    plt.savefig(path, dpi=150, bbox_inches="tight"); plt.close()
    print(f"[✓] Saved  →  {path}")


# ── SAVE REPORTS ─────────────────────────────────────────────
def save_reports(df_flagged, prod_df, state_df, discount_df):
    os.makedirs(REPORT_DIR, exist_ok=True)

    # Transaction anomalies
    anom_txn = df_flagged[df_flagged["anomaly_flag"] == 1].copy()
    anom_txn = anom_txn.sort_values("anomaly_score")
    anom_txn.to_csv(f"{REPORT_DIR}/anomaly_transactions.csv", index=False)
    print(f"[✓] anomaly_transactions.csv saved  ({len(anom_txn):,} rows)")

    # Product flags
    prod_df.to_csv(f"{REPORT_DIR}/product_anomaly_flags.csv", index=False)

    # State flags
    state_df.to_csv(f"{REPORT_DIR}/state_anomaly_flags.csv", index=False)

    # High discount
    discount_df.to_csv(f"{REPORT_DIR}/high_discount_orders.csv", index=False)
    print(f"[✓] All anomaly reports saved  →  reports/")


# ── PIPELINE ─────────────────────────────────────────────────
def run_pipeline():
    print("\n" + "=" * 60)
    print("  SUPERSTORE — ANOMALY DETECTION PIPELINE")
    print("=" * 60)

    df                      = load_data()
    df_flagged              = detect_transaction_anomalies(df)
    prod_df, prod_anomalies = detect_product_anomalies(df)
    state_df, state_anom    = detect_state_anomalies(df)
    discount_df             = detect_discount_anomalies(df)

    plot_anomaly_scatter(df_flagged)
    plot_product_flags(prod_df)
    plot_discount_loss(discount_df)

    save_reports(df_flagged, prod_df, state_df, discount_df)

    print("\n── ANOMALY SUMMARY ───────────────────────────────")
    print(f"  Flagged transactions  : {df_flagged['anomaly_flag'].sum():,}")
    print(f"  Loss sub-categories   : {(prod_df['Profit'] < 0).sum()}")
    print(f"  Loss states           : {(state_df['Profit'] < 0).sum()}")
    print(f"  High-discount orders  : {len(discount_df):,}")
    print(f"\n[✓] Anomaly detection complete.\n")

    return df_flagged, prod_df, state_df


if __name__ == "__main__":
    run_pipeline()
