"""
================================================================
  Retail Sales Intelligence Platform
  Module : eda.py  —  Exploratory Data Analysis
  Dataset: Kaggle Superstore (real 9,994 transactions)
================================================================
"""

import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker
import os

CLEAN_PATH = "data/clean_superstore.csv"
BI_PATH    = "data/superstore_bi.csv"
CHART_DIR  = "reports/charts"


# ── UTILS ────────────────────────────────────────────────────
def _save(name: str) -> None:
    os.makedirs(CHART_DIR, exist_ok=True)
    path = f"{CHART_DIR}/{name}"
    plt.tight_layout()
    plt.savefig(path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"   [✓] {path}")


def _fmt_k(x, _):  return f"${x/1_000:.0f}K"
def _fmt_m(x, _):  return f"${x/1_000_000:.1f}M"


def load(path: str = BI_PATH) -> pd.DataFrame:
    df = pd.read_csv(path, parse_dates=["order_date", "ship_date"])
    print(f"[✓] Loaded  →  {len(df):,} rows")
    return df


# ── CONSOLE KPIs ─────────────────────────────────────────────
def print_kpis(df: pd.DataFrame) -> None:
    total_sales    = df["sales"].sum()
    total_profit   = df["profit"].sum()
    total_orders   = df["order_id"].nunique()
    total_customers= df["customer_id"].nunique()
    avg_order      = df.groupby("order_id")["sales"].sum().mean()
    margin         = total_profit / total_sales * 100
    loss_orders    = (df["profit"] < 0).sum()

    sep = "=" * 60
    print(f"\n{sep}\n  KEY PERFORMANCE INDICATORS\n{sep}")
    print(f"  Total Sales          : ${total_sales:>12,.2f}")
    print(f"  Total Profit         : ${total_profit:>12,.2f}")
    print(f"  Total Orders         : {total_orders:>13,}")
    print(f"  Total Customers      : {total_customers:>13,}")
    print(f"  Avg Order Value      : ${avg_order:>12,.2f}")
    print(f"  Profit Margin        : {margin:>12.2f} %")
    print(f"  Loss-making Rows     : {loss_orders:>13,}")
    print(sep)


def print_region(df):
    print("\n" + "="*60 + "\n  REGION ANALYSIS\n" + "="*60)
    tbl = (df.groupby("region")
             .agg(Sales=("sales","sum"), Profit=("profit","sum"),
                  Orders=("order_id","nunique"))
             .sort_values("Sales", ascending=False))
    tbl["Margin%"] = (tbl["Profit"] / tbl["Sales"] * 100).round(2)
    print(tbl.round(2).to_string())


def print_category(df):
    print("\n" + "="*60 + "\n  CATEGORY ANALYSIS\n" + "="*60)
    tbl = (df.groupby("category")
             .agg(Sales=("sales","sum"), Profit=("profit","sum"),
                  Orders=("order_id","nunique"), Avg_Sales=("sales","mean"))
             .sort_values("Sales", ascending=False))
    tbl["Margin%"] = (tbl["Profit"] / tbl["Sales"] * 100).round(2)
    print(tbl.round(2).to_string())


def print_subcategory(df):
    print("\n" + "="*60 + "\n  SUB-CATEGORY ANALYSIS\n" + "="*60)
    tbl = (df.groupby("sub_category")
             .agg(Sales=("sales","sum"), Profit=("profit","sum"))
             .sort_values("Profit", ascending=False))
    tbl["Margin%"] = (tbl["Profit"] / tbl["Sales"] * 100).round(2)
    print(tbl.round(2).to_string())


def print_segment(df):
    print("\n" + "="*60 + "\n  SEGMENT ANALYSIS\n" + "="*60)
    tbl = (df.groupby("segment")
             .agg(Sales=("sales","sum"), Profit=("profit","sum"),
                  Customers=("customer_id","nunique"))
             .sort_values("Sales", ascending=False))
    print(tbl.round(2).to_string())


# ── CHARTS ───────────────────────────────────────────────────

def chart_sales_by_region(df):
    data = df.groupby("region")["sales"].sum().sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(8, 5))
    colors = ["#1565C0","#2196F3","#64B5F6","#BBDEFB"]
    bars = ax.bar(data.index, data.values, color=colors, edgecolor="white", linewidth=1.2)
    ax.bar_label(bars, fmt="$%.0f", padding=4, fontsize=9, fontweight="bold")
    ax.set_title("Total Sales by Region", fontsize=15, fontweight="bold", pad=12)
    ax.set_ylabel("Sales ($)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("01_sales_by_region.png")


def chart_profit_by_region(df):
    data = df.groupby("region")["profit"].sum().sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(8, 5))
    colors = ["#2E7D32","#43A047","#81C784","#C8E6C9"]
    bars = ax.bar(data.index, data.values, color=colors, edgecolor="white")
    ax.bar_label(bars, fmt="$%.0f", padding=4, fontsize=9, fontweight="bold")
    ax.set_title("Total Profit by Region", fontsize=15, fontweight="bold", pad=12)
    ax.set_ylabel("Profit ($)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("02_profit_by_region.png")


def chart_category_comparison(df):
    cat = (df.groupby("category")[["sales","profit"]].sum()
             .sort_values("sales", ascending=False))
    x = np.arange(len(cat)); w = 0.38
    fig, ax = plt.subplots(figsize=(9, 5))
    b1 = ax.bar(x - w/2, cat["sales"],  width=w, label="Sales",  color="#1565C0")
    b2 = ax.bar(x + w/2, cat["profit"], width=w, label="Profit", color="#2E7D32")
    ax.bar_label(b1, fmt="$%.0f", padding=3, fontsize=8)
    ax.bar_label(b2, fmt="$%.0f", padding=3, fontsize=8)
    ax.set_xticks(x); ax.set_xticklabels(cat.index, fontsize=11)
    ax.set_title("Sales vs Profit by Category", fontsize=15, fontweight="bold", pad=12)
    ax.set_ylabel("Amount ($)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax.legend(fontsize=10)
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("03_category_comparison.png")


def chart_subcategory_profit(df):
    data = (df.groupby("sub_category")["profit"].sum()
              .sort_values(ascending=True))
    colors = ["#F44336" if v < 0 else "#43A047" for v in data.values]
    fig, ax = plt.subplots(figsize=(10, 7))
    bars = ax.barh(data.index, data.values, color=colors, edgecolor="white")
    ax.axvline(0, color="black", linewidth=0.8)
    ax.set_title("Profit by Sub-Category\n(Red = Loss)", fontsize=14, fontweight="bold")
    ax.set_xlabel("Profit ($)")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax.grid(axis="x", alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("04_subcategory_profit.png")


def chart_monthly_trend(df):
    monthly = (df.groupby(df["order_date"].dt.to_period("M"))
                 .agg(Sales=("sales","sum"), Profit=("profit","sum")))
    idx = monthly.index.astype(str)
    fig, ax1 = plt.subplots(figsize=(14, 5))
    ax2 = ax1.twinx()
    ax1.plot(idx, monthly["Sales"],  color="#1565C0", linewidth=2.2,
             marker="o", markersize=4, label="Sales")
    ax1.fill_between(idx, monthly["Sales"], alpha=0.1, color="#1565C0")
    ax2.plot(idx, monthly["Profit"], color="#2E7D32", linewidth=2,
             linestyle="--", marker="s", markersize=3, label="Profit")
    ax1.set_title("Monthly Sales & Profit Trend", fontsize=15, fontweight="bold")
    ax1.set_ylabel("Sales ($)", color="#1565C0")
    ax2.set_ylabel("Profit ($)", color="#2E7D32")
    ax1.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax2.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    plt.xticks(rotation=45, ha="right", fontsize=7)
    lines1, labels1 = ax1.get_legend_handles_labels()
    lines2, labels2 = ax2.get_legend_handles_labels()
    ax1.legend(lines1 + lines2, labels1 + labels2, loc="upper left")
    ax1.grid(alpha=0.3)
    _save("05_monthly_trend.png")


def chart_top10_states(df):
    data = (df.groupby("state")["sales"].sum()
              .sort_values(ascending=True).tail(10))
    fig, ax = plt.subplots(figsize=(10, 6))
    bars = ax.barh(data.index, data.values,
                   color=plt.cm.Blues(np.linspace(0.4, 0.9, len(data))))
    ax.bar_label(bars, fmt="$%.0f", padding=4, fontsize=8)
    ax.set_title("Top 10 States by Sales", fontsize=15, fontweight="bold")
    ax.set_xlabel("Sales ($)")
    ax.xaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax.grid(axis="x", alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("06_top10_states.png")


def chart_segment_pie(df):
    data = df.groupby("segment")["sales"].sum()
    colors = ["#1565C0","#43A047","#FB8C00"]
    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    axes[0].pie(data.values, labels=data.index, autopct="%1.1f%%",
                colors=colors, startangle=140,
                wedgeprops={"edgecolor":"white","linewidth":2})
    axes[0].set_title("Sales by Segment", fontsize=13, fontweight="bold")
    profit = df.groupby("segment")["profit"].sum()
    axes[1].pie(profit.values, labels=profit.index, autopct="%1.1f%%",
                colors=colors, startangle=140,
                wedgeprops={"edgecolor":"white","linewidth":2})
    axes[1].set_title("Profit by Segment", fontsize=13, fontweight="bold")
    _save("07_segment_pie.png")


def chart_discount_vs_profit(df):
    sample = df.sample(min(3000, len(df)), random_state=42)
    fig, ax = plt.subplots(figsize=(9, 6))
    cats   = sample["category"].unique()
    colors = {"Furniture":"#FB8C00","Office Supplies":"#1565C0","Technology":"#2E7D32"}
    for cat in cats:
        sub = sample[sample["category"] == cat]
        ax.scatter(sub["discount"], sub["profit"],
                   alpha=0.4, s=12, label=cat, color=colors.get(cat,"grey"))
    ax.axhline(0, color="red", linestyle="--", linewidth=1)
    ax.set_title("Discount vs Profit\n(Higher discount → More losses)",
                 fontsize=13, fontweight="bold")
    ax.set_xlabel("Discount")
    ax.set_ylabel("Profit ($)")
    ax.legend()
    ax.grid(alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("08_discount_vs_profit.png")


def chart_shipmode(df):
    data = df.groupby("ship_mode")[["sales","profit"]].sum().sort_values("sales")
    x = np.arange(len(data)); w = 0.38
    fig, ax = plt.subplots(figsize=(9, 5))
    b1 = ax.bar(x - w/2, data["sales"],  width=w, label="Sales",  color="#1565C0")
    b2 = ax.bar(x + w/2, data["profit"], width=w, label="Profit", color="#2E7D32")
    ax.bar_label(b1, fmt="$%.0f", padding=3, fontsize=8)
    ax.bar_label(b2, fmt="$%.0f", padding=3, fontsize=8)
    ax.set_xticks(x); ax.set_xticklabels(data.index, fontsize=10)
    ax.set_title("Sales & Profit by Ship Mode", fontsize=14, fontweight="bold")
    ax.set_ylabel("Amount ($)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    ax.legend(); ax.grid(axis="y", alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("09_shipmode.png")


def chart_quarterly_growth(df):
    q = (df.groupby(["order_year","quarter_label"])["sales"].sum()
           .reset_index()
           .sort_values(["order_year","quarter_label"]))
    q["label"] = q["order_year"].astype(str) + " " + q["quarter_label"]
    fig, ax = plt.subplots(figsize=(12, 5))
    ax.bar(q["label"], q["sales"],
           color=plt.cm.Blues(np.linspace(0.4, 0.9, len(q))))
    ax.set_title("Quarterly Sales Growth", fontsize=14, fontweight="bold")
    ax.set_ylabel("Sales ($)")
    ax.yaxis.set_major_formatter(mticker.FuncFormatter(_fmt_k))
    plt.xticks(rotation=30, ha="right", fontsize=8)
    ax.grid(axis="y", alpha=0.3)
    ax.spines[["top","right"]].set_visible(False)
    _save("10_quarterly_growth.png")


# ── MAIN ─────────────────────────────────────────────────────
def run_eda() -> None:
    print("\n" + "="*60)
    print("  SUPERSTORE — EXPLORATORY DATA ANALYSIS")
    print("="*60)
    df = load()
    print_kpis(df)
    print_region(df)
    print_category(df)
    print_subcategory(df)
    print_segment(df)

    print("\n[→] Generating 10 charts …")
    chart_sales_by_region(df)
    chart_profit_by_region(df)
    chart_category_comparison(df)
    chart_subcategory_profit(df)
    chart_monthly_trend(df)
    chart_top10_states(df)
    chart_segment_pie(df)
    chart_discount_vs_profit(df)
    chart_shipmode(df)
    chart_quarterly_growth(df)
    print("\n[✓] All 10 charts saved to reports/charts/\n")


if __name__ == "__main__":
    run_eda()
