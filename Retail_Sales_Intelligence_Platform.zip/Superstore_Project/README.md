# 📊 Retail Sales Intelligence Platform
### End-to-End Data Analytics & Business Intelligence — Kaggle Superstore Dataset

![Python](https://img.shields.io/badge/Python-3.10+-3776AB?style=flat&logo=python&logoColor=white)
![Pandas](https://img.shields.io/badge/Pandas-2.0+-150458?style=flat&logo=pandas&logoColor=white)
![Streamlit](https://img.shields.io/badge/Streamlit-1.35+-FF4B4B?style=flat&logo=streamlit&logoColor=white)
![SQLite](https://img.shields.io/badge/SQLite-3-003B57?style=flat&logo=sqlite&logoColor=white)
![Prophet](https://img.shields.io/badge/Prophet-1.1.5+-0078D7?style=flat)
![Scikit--learn](https://img.shields.io/badge/Scikit--learn-1.3+-F7931E?style=flat&logo=scikit-learn&logoColor=white)
![License](https://img.shields.io/badge/License-MIT-green?style=flat)
![Dataset](https://img.shields.io/badge/Dataset-Kaggle_Superstore-20BEFF?style=flat&logo=kaggle)

---

## 🎯 Project Overview

A **production-grade, end-to-end Retail Sales Intelligence platform** built on the **real Kaggle Superstore dataset** (9,994 transactions). Covers the complete modern analytics lifecycle:

```
Raw CSV → Cleaning → EDA → SQL Analysis → RFM Segmentation
         → Anomaly Detection (ML) → Prophet Forecasting → 7-Tab Dashboard
```

> **Built for Senior Data Analytics / Business Intelligence roles.**

---

## 📁 Project Structure

```
Retail_Sales_Intelligence_Platform/
│
├── 📂 data/
│   ├── superstore.csv                  ← Raw Kaggle dataset
│   ├── clean_superstore.csv            ← Cleaned & type-cast
│   └── superstore_bi.csv               ← Enriched with date features
│
├── 📂 sql/
│   └── superstore_analysis.sql         ← 16 production SQL queries
│
├── 📂 reports/
│   ├── executive_report.csv
│   ├── business_insights.txt
│   ├── customer_segmentation.csv
│   ├── rfm_analysis.csv
│   ├── sales_forecast.csv              ← Prophet 90-day output
│   ├── forecast_summary.csv
│   ├── anomaly_transactions.csv        ← Isolation Forest output
│   ├── product_anomaly_flags.csv
│   ├── state_anomaly_flags.csv
│   └── 📂 charts/                      ← 11 Matplotlib PNGs
│
├── 📂 notebooks/
│   └── Superstore_Analysis.ipynb       ← Full EDA + ML notebook
│
├── data_cleaning.py                    ← Clean + enrich pipeline
├── eda.py                              ← 10 EDA charts + analysis
├── business_analysis.py                ← SQL + RFM + Reports
├── forecasting.py                      ← Prophet 90-day forecast
├── anomaly_detection.py                ← Isolation Forest + rules
├── app.py                              ← 7-tab Streamlit dashboard
├── requirements.txt
├── .gitignore
├── CONTRIBUTING.md
└── README.md
```

---

## 📊 Dataset

| Field | Detail |
|---|---|
| **Source** | [Kaggle — Sample Superstore](https://www.kaggle.com/datasets/vivek468/superstore-dataset-final) |
| **Rows** | 9,994 real transactions |
| **Columns** | 21 |
| **Date Range** | 2014 – 2017 |
| **Geography** | 49 US States, 531 Cities |
| **Customers** | 793 unique buyers |

---

## 💰 Key Business KPIs

| KPI | Value |
|---|---|
| **Total Sales** | $2,297,200 |
| **Total Profit** | $286,397 |
| **Profit Margin** | 12.47% |
| **Total Orders** | 5,009 |
| **Top Region** | West ($725K) |
| **Top Category** | Technology (17.4% margin) |
| **Loss Sub-Categories** | Tables, Bookcases |

---

## 🏗️ Module Breakdown

### `data_cleaning.py`
Loads raw CSV → parses dates → renames snake_case → drops unused columns → derives `profit_margin_pct`, `ship_days`, `is_profitable`, time features.

### `eda.py`
10 analysis charts: region, category, sub-category, monthly trend, top states, segment, discount impact, ship mode, quarterly growth.

### `business_analysis.py`
SQLite + 16 SQL queries + RFM segmentation (Champions/Loyal/At Risk/Lost) + executive report CSV + TXT.

### `forecasting.py`
Prophet 90-day sales forecast with multiplicative seasonality, 95% CI, weekly/yearly component plots, CSV export.

```bash
python forecasting.py
# Output: reports/sales_forecast.csv, reports/forecast_summary.csv
```

### `anomaly_detection.py`
Isolation Forest on 5 features (Sales, Profit, Discount, Quantity, Margin) + rule-based product/state flags.

```bash
python anomaly_detection.py
# Output: reports/anomaly_transactions.csv, product_anomaly_flags.csv
```

### `app.py` — 7-Tab Streamlit Dashboard

| Tab | Content |
|---|---|
| 📊 Overview | 7 dynamic KPI cards, region bar, category pie, monthly trend, 5 filter-aware insights |
| 🏷️ Category & Products | Sub-cat profit waterfall, Category×Region heatmap, Discount scatter |
| 🗺️ Geography | Top 10 states revenue/profit, Region grouped bar + margin, State table |
| 👥 Customers & RFM | RFM KPIs, segment distribution, revenue by segment, top 10, full table |
| 🔍 Data Explorer | Column picker, row slider, CSV + Executive report download |
| 🚨 Anomaly Detection | Isolation Forest scatter, sub-category flags, loss-states chart, flagged table + CSV |
| 📈 Forecasting | 90-day forecast + CI, weekly/yearly seasonality, forecast table + CSV download |

---

## 🚀 Quick Start

```bash
# 1. Clone
git clone https://github.com/yourusername/Retail-Sales-Intelligence-Platform.git
cd Retail-Sales-Intelligence-Platform

# 2. Virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install
pip install -r requirements.txt

# 4. Add dataset → data/superstore.csv

# 5. Run full pipeline
python data_cleaning.py
python eda.py
python business_analysis.py
python anomaly_detection.py
python forecasting.py

# 6. Launch dashboard
streamlit run app.py
```

---

## 🛠️ Tech Stack

| Tool | Purpose |
|---|---|
| **Python 3.10+** | Core |
| **Pandas 2.0+** | Data wrangling |
| **Matplotlib 3.7+** | Visualizations |
| **SQLite3** | SQL analysis |
| **Streamlit 1.35+** | Dashboard |
| **Prophet 1.1.5+** | Time-series forecasting |
| **Scikit-learn 1.3+** | Anomaly detection (Isolation Forest) |
| **Jupyter** | Exploratory notebook |

---

## 🔍 Key Business Insights

1. **Discounts > 20%** → consistent negative profit. Discount policy is broken.
2. **Tables & Bookcases** are net loss-makers — pricing review needed.
3. **Texas** = high revenue, negative profit — anomaly confirmed by Isolation Forest.
4. **Q4 (Oct–Dec)** shows strong seasonality every year — confirmed by Prophet.
5. **At Risk RFM segment** — win-back campaigns needed before customers are Lost.
6. **5% of transactions** are statistical anomalies — mostly high-discount furniture orders.

---

## 📜 License

MIT License — free to use, modify, and distribute.

---

*Retail Sales Intelligence Platform — raw data to ML-powered forecasting dashboard.*
